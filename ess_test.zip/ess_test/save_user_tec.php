<?php
include "config/config.php";

date_default_timezone_set('Asia/Kolkata');

$tec_id = $_POST['tec_id'];
$project_id = $_POST['project_id'];
$base_location = $_POST['base_location'];
$travel_date = $_POST['travel_date'];
$from_location = $_POST['from_location'];
$to_location = $_POST['to_location'];
$kilo_meter = $_POST['kilo_meter'];
$mileage = $_POST['mileage'];
$departure_date = $_POST['deprt_date'];
$departure_time = $_POST['deprt_time'];
$arrival_time = $_POST['arrival_time'];
$arrival_date = $_POST['arrival_date'];
$role_id = $_POST['role_id'];
$entry_id = $_POST['entry_id'];
$entry_category = $_POST['entry_category'];
$travel_mode = $_POST['travel_mode'];
$location = $_POST['location'];
$unit_price = $_POST['unit_price'];
$total_quantitty = $_POST['total_quantitty'];
$description = $_POST['description'];
$date = $_POST['date'];
$paid_to = $_POST['paid_to'];
$paid_by = $_POST['paid_by'];
$gstin = $_POST['gstin'];
$bill_amount = $_POST['bill_amount'];
$bill_num = $_POST['bill_num'];
$is_billable = $_POST['is_billable'];
$is_metro = $_POST['is_metro'];
$paid_to_id = $_POST['paid_to_id'];
$created_by_id = $_POST['created_by_id'];

$current_date = date("Y-m-d h:m:s");
$request_date = date("Y-m-d");


$fileName = "";
$filePath = "";
$basePath = "http://ess.technitab.in/web_service/ESS/tec/";

$insertEntryId = 0;


//echo "entry_id ".$entry_id;


if(isset($_FILES["file"]["type"])){
	if (($_FILES["file"]["type"] == "application/pdf") && ($_FILES["file"]["size"] < 2097152)) {

$entry_id = generateTECEntryId($con,$tec_id,$entry_category,$from_location,$to_location,$kilo_meter,$mileage,$travel_mode,$location,$departure_date, $departure_time,$arrival_date,$arrival_time,$unit_price,$total_quantitty,$description,$date,$paid_to,$paid_by,$gstin,$bill_amount,$bill_num,$created_by_id,$current_date,$is_metro,$is_billable,$paid_to_id);

$sourcePath = $_FILES['file']['tmp_name']; // Storing source path of the file in a variable

$extension = getFileExtension($_FILES["file"]["name"]);
$fileName = $tec_id.'_'.$entry_id.'_'.$entry_category.'.'.$extension;

$targetPath = $_SERVER['DOCUMENT_ROOT']."/web_service/ESS/tec/".$fileName; // Target path where file is to be stored
move_uploaded_file($sourcePath,$targetPath) ; // Moving Uploaded file
$image_path = $basePath.$fileName;

//echo "image path ".$image_path;

$res = $con->query("UPDATE `emp_tec_entry` set `attachment_path` = '$image_path' WHERE `id` = '$entry_id'");

if ($con->affected_rows >0) {
	$insertEntryId = $entry_id;
}


/*$result_log = $con->query("INSERT into `emp_tec_log` (`tec_id`,`status`,`created_date`,`created_by_id`) VALUES ('$tec_id','tec created','$request_date','$role_id')");
*/
}
} else if ($bill_amount > 100 && !($entry_category == "Food - Boarding - Per Diem" || $entry_category == "Local Travel - Public transport" || $entry_category == "Fuel/Mileage Expenses - Own transport" || $travel_mode == "Metro" || $travel_mode == "Auto")) {
	$insertEntryId = -1;
}else {

$entry_id = generateTECEntryId($con,$tec_id,$entry_category,$from_location,$to_location,$kilo_meter,$mileage,$travel_mode,$location,$departure_date, $departure_time,$arrival_date,$arrival_time,$unit_price,$total_quantitty,$description,$date,$paid_to,$paid_by,$gstin,$bill_amount,$bill_num,$created_by_id,$current_date,$is_metro,$is_billable,$paid_to_id);

	$insertEntryId = $entry_id;
}

$response = array();

//echo "insertEntryId ".$insertEntryId;

if ($insertEntryId>0) {
	$response['eror'] = false;
	$response['message'] = "Successfully TEC entry saved";
	$response['id'] = $insertEntryId;
	$response['tec_id'] = $tec_id;
updateTotalAmount($con,$tec_id,$bill_amount);

if(!isSameUser($con,$tec_id,$created_by_id)){
	sendNotification($con,$tec_id,$entry_category,$created_by_id);
}

}else if($insertEntryId == -1){
	$response['eror'] = true;
	$response['message'] = "Bill is required";
	$response['id'] = "0";
	$response['tec_id'] = "0";
}else{
	$response['eror'] = true;
	$response['message'] = "TEC is not saved".$con->error;
	$response['id'] = "0";
	$response['tec_id'] = "0";
}


echo json_encode($response);


function isSameUser($con,$tec_id,$created_by_id){
	$valid = true;
	$result = $con->query("SELECT * from `emp_main_tec` where `id` = '$tec_id'");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_assoc()) {
			$mainUserId = $row['created_by_id'];
			if ($mainUserId != $created_by_id) {
				$valid = false;
			}
		}
	}
	return $valid;
}

function updateTotalAmount($con,$tec_id,$bill_amount){
	$result = $con->query("UPDATE `emp_main_tec` set `total_amount` = (`total_amount` + $bill_amount) WHERE `id` = '$tec_id'");
}


function generateTECId($con,$project_id,$role_id,$date,$current_date,$base_location,$travel_date){
	$insert_id = 0;
	$query = "INSERT into `emp_main_tec` (`role_id`, `project_id`,`request_date`,`base_location`,`travel_date`,`status`, `created_date`, `created_by_id`) VALUES ('$role_id', '$project_id', '$date', '$base_location', '$travel_date', 'draft', '$current_date','$role_id')";


	if ($con->query($query) === TRUE) {
		$insert_id = $con->insert_id;
	}

	return $insert_id;
}

function generateTECEntryId($con,$tec_id,$entry_category,$from_location,$to_location,$kilo_meter,$mileage,$travel_mode,$location,$departure_date, $departure_time,$arrival_date,$arrival_time,$unit_price,$total_quantitty,$description,$date,$paid_to,$paid_by,$gstin,$bill_amount,$bill_num,$created_by_id,$current_date,$is_metro,$is_billable,$paid_to_id){
	
	$entry_id = 0;
	$query = "INSERT into `emp_tec_entry` (`tec_id`, `entry_category`,`from_location`,`to_location`,`kilo_meter`,`mileage`,`travel_mode`,`location`,`deprt_date`,`deprt_time`,`arrival_date`,`arrival_time`,`unit_price`, `total_quantitty`, `description`,`date`,`paid_to`,`paid_by`,`gstin`,`bill_amount`,`bill_num`,`attachment_path`,`created_by_id`,`created_date`,`is_metro`,`is_billable`,`paid_to_id`) VALUES ('$tec_id','$entry_category','$from_location','$to_location','$kilo_meter','$mileage','$travel_mode','$location','$departure_date', '$departure_time','$arrival_date','$arrival_time','$unit_price','$total_quantitty','$description','$date','$paid_to','$paid_by','$gstin','$bill_amount','$bill_num','','$created_by_id','$current_date','$is_metro','$is_billable','$paid_to_id')";

	if ($con->query($query) === TRUE) {
		$entry_id = $con->insert_id;
	}	
	return $entry_id;
}

function getFileExtension($file)
{

	$path_parts = pathinfo($file);
    //get extension
	return $path_parts['extension'];
}



function getUserData($con,$role_id){
	$userArray = array();
	$result = $con->query("SELECT * from `user` WHERE `id` = '$id'");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_assoc()) {
			$userArray['name'] = $row['name'];
			$userId = $row['id'];
		}
	}
	return $userArray;
}


function sendNotification($con,$tec_id,$entry_category,$created_by_id){
	$userData = getUserData($con,$role_id);
	
	$ss= $con->query("SELECT uft.`token` from `emp_main_tec` as u JOIN `user_fcm_token` as uft on u.`created_by_id` = uft.`user_id`");  

	$ch = curl_init("https://fcm.googleapis.com/fcm/send");

	$serverKey = "AIzaSyDJ0MiSBWBsQN5y-ybhWr2GNGFzTPsSfFQ";

	$notificationArr = array();
	array_push($notificationArr,array("entry_category"=>$entry_category,"user_name"=>$userData['name']));

	$notification = array("body" => array("module"=>"Add Tec","json_response"=>$notificationArr));

	while($r= ($ss->fetch_array())) {

		$f = $r['token'];
		$arrayToSend = array('to' => $f, 'data' => $notification);

		$json = json_encode($arrayToSend);
      // echo $json;
		$headers = array();
		$headers[] = "Content-Type: application/json";
		$headers[] = "Authorization: key= $serverKey";

		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
		curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$result = curl_exec($ch);
		if($result === false)
		{
            //echo  'Curl failed ' . curl_error($ch);
		}

	}
	curl_close($ch);


}


?>