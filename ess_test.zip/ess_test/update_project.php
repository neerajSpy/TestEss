<?php
include "config/config.php";
date_default_timezone_set('Asia/Kolkata');

$project_id = $_POST['project_id'];
$user_id = $_POST['user_id'];
$client_name = $_POST['client_name'];
$customer_id = $_POST['customer_id'];
$customer_name = $_POST['customer_name'];
$project_name = $_POST['project_name'];
$billing_type = $_POST['billing_type'];
$budget_amount = $_POST['budget_amount'];
$project_type_id = $_POST['project_type_id'];
$description = $_POST['description'];

$project_budget_hours = $_POST['project_budget_hours'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$action = $_POST['action'];

$date = new DateTime($end_date);
$now = new DateTime($start_date);

$days = $date->diff($now)->format("%d");
$current_code = "INR";
$budget_type = "No Budget";

$response = array();

$now = new DateTime();
$current_date =  $now->format('Y-m-d H:i:s');


if ($budget_amount == "") {
    $budget_amount = 0;
}

$update_project_id = -1;

$emailResponse =array('user_id' =>$user_id,'customer_name'=>$customer_name,'project_name' =>$project_name,'project_type_id'=>$project_type_id,"billing_type"=>$billing_type,"budget_amount"=>$budget_amount,'project_budget_hours'=>$project_budget_hours,'start_date'=>$start_date,'end_date'=>$end_date,'description'=>$description);


//SELECT `id`, `Project Name`, `Description`, `Billing Type`, `Project Cost`, `Customer Name`, `cust_id`,
// `Currency Code`, `project_type_id`, `Budget Type`, `Budget Amount`, `Project Budget Hours`, `CF.Estimated Days`,
// `tl_ts_approver_id`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `created_by`,
// `modified_by`, `is_active`, `created_date`, `modified_date`, `project_status` FROM `master_zoho_project` WHERE 1

if(strtolower($action) == "submit" || strtolower($action) == "update"){   
    $update_result = $con->query("UPDATE `temp_project` set `Project Name` = '$project_name', `Description`= '$description', `Billing Type`= '$billing_type',`Budget Amount`='$budget_amount',`Budget Type`= '$budget_type',`Customer Name`='$customer_name', `cust_id`='$customer_id',`Currency Code`='$current_date',`project_type_id`='$project_type_id',`CF.Estimated Days`='days',`planned_start_date`='$planned_start_date',`planned_end_date`='$planned_end_date',`modified_by`='$user_id',`modified_date`='$current_date',`Project Budget Hours`='$project_budget_hours' WHERE `id` = '$project_id'");

    if ($con->affected_rows >0) {
        $update_project_id = 1;
    }else {
        $update_project_id = 0;
    }

}else{

$result = $con->query("SELECT * from `master_zoho_project` where `Project Name` = '$project_name' AND `project_type_id` = '$project_type_id'");


if ($result->num_rows < 1) {
    
    $insert_query = "INSERT INTO `master_zoho_project` (`Project Name`, `Description`, `Billing Type`,`Budget Amount`,`Budget Type`,`Customer Name`, `cust_id`,`Currency Code`,`project_type_id`,`CF.Estimated Days`,`planned_start_date`,`planned_end_date`,`created_by`,`created_date`,`Project Budget Hours`) VALUES ('$project_name', '$description','$billing_type','$budget_amount','$budget_type','$customer_name','$customer_id','$current_code','$project_type_id','$days','$start_date','$end_date','$user_id','$current_date','$project_budget_hours')";

    if ($con->query($insert_query) === TRUE) {
        $id = $con->insert_id;
        
        $project_type_list = $con->query("SELECT * from `project_type_activity_type` WHERE `project_type_id` = '$project_type_id'");

        if ($project_type_list->num_rows >0) {

            while ($row = $project_type_list->fetch_array()) {
                $activity_type_id = $row['id'];
                $query = "INSERT INTO `activity` (`project_id`,`project_type_id`,`activity_type_id`,`created_by_id`,`created_date`) VALUES('$id','$project_type_id','$activity_type_id','$user_id','$current_date')";

                if ($con->query($query) === TRUE) {
                    $update_project_id = $con->insert_id;
                }
            }

            $con->query("UPDATE `temp_project` set `is_active` = '1' WHERE `id` = '$project_id'");
        }

    }

}
}

if ($update_project_id > 0) {
    $response['error'] = false;
    $response['message'] = "Successfully Saved.";

    if (strtolower($action) == "submit" || strtolower($action) == "update") {
    sendNotification($con,$user_id,$project_name);
    sendEmail($con,$emailResponse);
    }

}else if ($project_id == -1){
    $response['error'] = true;
    $response['message'] = "Project not saved. Duplicate project or project type";
}else{
    $response['error'] = true;
    $response['message'] = "Project not updated.";
}

echo json_encode($response);



function sendNotification($con,$user_id,$project_name){
    $userData = getUserArray($con,$user_id);
    $token_query = "SELECT uft.`token`  from `user` as u JOIN `user_fcm_token` as uft on u.`id` = uft.`user_id` WHERE u.`access_control_id` = 2";
    $ss= $con->query($token_query);

    $ch = curl_init("https://fcm.googleapis.com/fcm/send");
    $serverKey = "AIzaSyDJ0MiSBWBsQN5y-ybhWr2GNGFzTPsSfFQ";

    $notificationArr = array();
    array_push($notificationArr,array("project_name"=>$project_name,"user_name"=>$userData['name']));

    $notification = array("body" => array("module"=>"Request Add Project","json_response"=>$notificationArr));

    while($r= ($ss->fetch_array())) {

        $f = $r['token'];
        $arrayToSend = array('to' => $f, 'data' => $notification);

        $json = json_encode($arrayToSend);
      // echo $json;
        $headers = array();
        $headers[] = "Content-Type: application/json";
        $headers[] = "Authorization: key= $serverKey";

        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
        curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($ch);
        if($result === false)
        {
            //echo  'Curl failed ' . curl_error($ch);
        }

    }
    curl_close($ch);
}


function getUserArray($con,$user_id){
    $userArray = array();
    $result = $con->query("SELECT * from `user` WHERE `id` = '$user_id'");
        if($row = $result->fetch_array()){
            $userArray = $row;
        }
        
    return $userArray;
}

function getProjectType($con,$type_id){
    $type = "";
    $result = $con->query("SELECT * From `project_type` WHERE `id` = '$type_id'");
    if ($result->num_rows >0) {
        if ($row = $result->fetch_assoc()) {
            $type = $row['type'];
        }
    }
    return $type;
}

function sendEmail($con,$emailResponse){

//('user_id' => ,$user_id,'customer_name'=>$customer_name,'project_name' =>$project_name,'project_type_id'=>$project_type_id,"billing_type"=>$billing_type,"budget_amount"=>$budget_amount,'project_budget_hours'=>$project_budget_hours,'start_date'=>$start_date,'end_date'=>$end_date,'description'=>$description)
$project_type = getProjectType($con,$emailResponse['project_type_id']);
$userArray = getUserArray($con,$emailResponse['user_id']);

// Multiple recipients
$to =  "ranju.kumari@technitab.in, kavinder.kohli@technitab.com"; // note the comma
$from = $userArray['email'];

// Subject
$subject = 'Add project Request : '.$userArray['name'];

// Message
$message = '
<html>

<body>
Dear Admin,
<p>Please approve the following project request submitted by '.$userArray['name'].' as per information below </p>
Customer Name : '.$emailResponse['customer_name'].'<br>
Project Name : '.$emailResponse['project_name'].'<br>
Project Type : '.$project_type.'<br>
Billing Type : '.$emailResponse['billing_type'].'<br>
Budget Amount : '.$emailResponse['budget_amount'].'<br>
Project Budget hour : '.$emailResponse['project_budget_hours'].'<br>
Start date : '.$emailResponse['start_date'].'<br>
End date : '.$emailResponse['end_date'].'<br>
Description : '.$emailResponse['description'].'<br>

<p></p>
Regards.<br>
Ess App
</body>
</html>
';

// To send HTML mail, the Content-type header must be set
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-type: text/html; charset=iso-8859-1';

// Additional headers
$headers[] = 'To: '.$To;
$headers[] = 'From: '.$userArray['name'].' '.$userArray['email'];
$headers[] = 'Bcc: neeraj.kumar@technitab.in';
/*$headers[] = 'Bcc: birthdaycheck@example.com';*/

// Mail it
mail($to, $subject, $message, implode("\r\n", $headers));

}


?>