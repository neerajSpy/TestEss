<?php
include "config/config.php";

date_default_timezone_set('Asia/Kolkata');

$role_id = $_POST['role_id'];
$trip_id = $_POST['id'];
$project_id = $_POST['project_id'];
$claim_start_date = $_POST['claim_start_date'];
$base_location = $_POST['base_location'];
$site_location = $_POST['site_location'];
$created_by_id = $_POST['created_by_id'];


$date = date("Y-m-d h:m:s");

$response = array();


//SELECT `id`, `project_id`, `role_id`, `claim_start_date`, `base_location`, `site_location`, `claim_end_date`, `status`, `description`, `created_date`, `created_by_id`, `submit_by_id`, `submit_date`, `modified_date`, `modified_by_id` FROM `emp_main_tec` WHERE 1

$insertId = -1;

$result = $con->query("SELECT * from `emp_main_tec` WHERE `created_by_id` = '$created_by_id' AND `project_id` = '$project_id' AND `claim_start_date` = '$claim_start_date'");
if ($result->num_rows < 1) {

$insertId = 0;

$query = "INSERT into `emp_main_tec` (`trip_id`,`role_id`, `project_id`,`claim_start_date`,`base_location`,`site_location`,`status`, `created_date`, `created_by_id`) VALUES ('$trip_id','$role_id','$project_id','$claim_start_date','$base_location','$site_location','draft','$date','$created_by_id')";


	if ($con->query($query) === TRUE) {
		$insertId = $con->insert_id;
	}
}

if ($insertId>0) {
	$response['id'] = $insertId;
	$response['eror'] = false;
	$response['message'] = "Successfully TCE id generated";
	
}else if ($insertId == -1){
	$response['id'] = "0";
	$response['eror'] = true;
	$response['message'] = "TCE id is already generated";
}else{
	$response['id'] = "0";
	$response['eror'] = true;
	$response['message'] = "TCE id not generated";
}


echo json_encode($response);
?>