<?php
include "config/config.php";
date_default_timezone_set('Asia/Kolkata');

$user_id = $_POST['user_id'];
$location = $_POST['in_location'];
$address = $_POST['in_address'];
$attendance = $_POST['attendance'];
$status = $_POST['punch_status'];
$punch_in = $_POST['punch_in']; 
$date_parts = preg_split('/\s+/', $punch_in);
$date = $date_parts[0];

$update_date = date("Y-m-d");
$response = array();

$last_id = 0;


$previousDate = getPreviousDate($date);
if(canPunchIn($con,$previousDate,$user_id) >0){
$exist_date_result = $con->query("SELECT * from `attendance` WHERE `user_id` = '$user_id' AND `date` = '$date'");
if ($exist_date_result->num_rows < 1) {
  $sql_query = "INSERT into `attendance` (`user_id`,`punch_in`,`attendance`,`date`,`update_date`,`punch_in_address`,`punch_in_location`,`status`) VALUES('$user_id','$punch_in','$attendance','$date','$update_date','$address','$location','$status')";

  if ($con->query($sql_query) === TRUE) {
    $last_id = $con->insert_id;
  }


  if ($last_id > 0) {
    $response['error'] = false;
    $response['message'] = "Successfully Saved";
  } else {
    $response['error'] = true;
    $response['message'] = "Not Saved!";
  }
} else {
  $response['error'] = true;
  $response['message'] = "Already punch in/out saved on this date!";
}
}else {
 $response['error'] = true;
  $response['message'] = "Fill your previous date timesheet."; 
}

echo json_encode($response);


function canPunchIn($con,$previousDate,$user_id){
  $punchPossible = 0;
  $canPunchIn = 0;

  while ($punchPossible == 0) {
    	if(isFirstDay($con,$user_id) < 1){
    		$canPunchIn = 1;
    		$punchPossible = 1;
    		break;
    	}else if (isTimesheetPresent($con,$previousDate,$user_id) >0) {
        //echo "present timesheet \n";
        $canPunchIn = 1;
        $punchPossible = 1;
        break;
      }else if(isUserOnLeave($con,$previousDate,$user_id) > 0 || isWeekDay($con,$previousDate) < 1){
        $previousDate = getPreviousDate($previousDate);
      //echo "check UserLeave ".$previousDate."\n";
      }else{
        //echo "check no \n";
        $canPunchIn = 0;
        $punchPossible = 2;
        break;
      }
    }
  //echo "punchPossible 1 yes 2 not poosible ".$punchPossible." canPunchIn ".$canPunchIn."\n";
  return $canPunchIn;
}


function isFirstDay($con,$user_id){
	$result = $con->query("SELECT * from `attendance` WHERE `user_id` = '$user_id'");
	return $result->num_rows;
}

function isWeekDay($con,$previousDate){
  //SELECT `id`, `Date`, `Day`, `State`, `Occasion` FROM `holiday_calendar` WHERE 1
  $result = $con->query("SELECT * from `holiday_calendar` WHERE `Date` = '$previousDate' AND `State` = 'weekday'");
  //echo "is Weekday ".$result->num_rows." date ".$previousDate."\n";
  return $result->num_rows;
}

function isUserOnLeave($con,$previousDate,$user_id){
  // SELECT `id`, `leave_request_id`, `user_id`, `leave_date`, `length_hours`, `length_days`, `duration_type`, `leave_status_id`, `comments`, `leave_type_id`, `start_time`, `end_time`, `date_applied`, `applied_by_id`, `status_date`, `status_by_id` FROM `user_leaves` WHERE 1
 $isUserOnLeave = false;
 $result = $con->query("SELECT * from `user_leaves` WHERE `user_id` = '$user_id' AND `leave_date` = '$previousDate' AND `leave_status_id` = '4'");
 //echo "isuserOnLeave ".$result->num_rows."\n";
 return $result->num_rows;
}

function isTimesheetPresent($con,$previousDate,$user_id){
  // SELECT `id`, `project_id`, `project_type_id`, `activity_type_id`, `activity_id`, `Project Name`, `Task Name`, `user_id`, `Staff Name`, `Email`, `Notes`, `Time Spent`, `Begin time`, `End time`, `Date`, `Billable Status`, `approve_status`, `approved_date`, `approve_by_id`, `create_date`, `create_by_id` FROM `zoho_timesheet` WHERE 1

  $result = $con->query("SELECT * from `zoho_timesheet` WHERE `Date` = '$previousDate' AND `user_id` = '$user_id'");
  //echo "timesheet present ".$result->num_rows."\n";
  return $result->num_rows;
}


function getPreviousDate($date){
  return date('Y-m-d', strtotime($date .' -1 day'));
}

?>
