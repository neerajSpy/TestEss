<?php
include "config/config.php";

$project_id = $_POST['project_id'];
$project_type_id = $_POST['project_type_id'];
$response = array();

	  	// SELECT `id`, `project_id`, `project_type_id`, `activity_type_id`, `Description`, `estimated_hrs`, `Is Billable`, `Task Rate Per Hour`, `Task Budget Hours`, `created_by_id`, `modified_by_id`, `is_active`, `created_date`, `modified_date`, `planned_start`, `actual_start`, `planned_end`, `actual_end`, `budget_hours`, `spent_hours` FROM `activity` WHERE 1


		//SELECT `id`, `activity_type`, `project_type_id`, `is_default`, `created_by`, `modified_by`, `is_active`, `created`, `modified` FROM `project_type_activity_type` WHERE 1

$exist_response = array();
$non_exist_response = array();

$project_type_list = $con->query("SELECT * from `project_type_activity_type` WHERE `project_type_id` = '$project_type_id'");

if ($project_type_list->num_rows >0) {

	while ($row = $project_type_list->fetch_array()) {
		$activity_type_id = $row['id'];
		$activity_type = $row['activity_type'];

		$invalide_query_result = $con->query("SELECT * from `activity` WHERE `project_id` = '$project_id' AND `project_type_id` = '$project_type_id' AND `activity_type_id` = '$activity_type_id'");

		if ($invalide_query_result->num_rows >0) {
			if ($inv_row = $invalide_query_result->fetch_array()) {
				array_push($exist_response,array("activity_type_id"=>$activity_type_id,"activity_type"=>$activity_type));
			}

		}else{
			array_push($non_exist_response,array("activity_type_id"=>$activity_type_id,"activity_type"=>$activity_type));
		}
	}
}

array_push($response, array("exist_activity"=>$exist_response,"non_exist_activity"=>$non_exist_response));
echo json_encode($response);

?>