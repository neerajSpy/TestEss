<?php
define('HOST_NAME','localhost');
define('DB_NAME','ess_test_app');
define('USERNAME','ess_admin');
define('PASSWORD','GBjio(*&^1');

?>