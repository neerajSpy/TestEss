<?php

//'localhost', 'ess_admin', 'Neeraj@123','ess_tt_app'

define('BASE_URL','http://ess.technitab.in/ESS/');
define('TEC','tec');
define('EXIST','-1');
define('QUERY_PROBLEM','-2');
define('TIMESHEET_REQUIRED','-3');
define('WEEKEND_HOLIDAY','-4');

define('IS_ACTIVE','0');
define('DEACTIVE','1');
define('INVALID_FILE','-5');
define('EXCEED_FILE_SIZE','-6');
define('INSUFFICIENT_LEAVE','-7');

define('UNAUTHORISED_USER','0');

?>