<?php
date_default_timezone_set('Asia/Kolkata');
include "config/config.php";


$response = array();

//SELECT `id`, `user_id`, `date`, `update_date`, `attendance`, `attendance_duration`, `timesheet_duration`, `punch_in`, `punch_out`, `manual_punch_in`, `manual_punchout`, `manual_punch_in_sys_time`, `manual_punch_out_sys_time`, `punch_in_photo_path`, `punch_out_photo_path`, `punch_in_address`, `punch_in_location`, `punch_out_address`, `punch_out_location`, `summery`, `status`, `is_active` FROM `attendance` WHERE 1


$result = $con->query("SELECT u.`name`, a.* from `attendance` as a JOIN `user` as u ON a.`user_id` = u.`id` WHERE a.`is_active` = '0'");

if ($result->num_rows >0) {
	while ($row = $result->fetch_assoc()) {
		array_push($response,array("name"=>$row['name'],"user_id"=>$row['user_id'],"date"=>$row['date'],"manual_punch_in"=>$row['manual_punch_in'],"manual_punchout"=>$row['manual_punchout'],"attendance"=>$row['attendance'],"attendance_duration"=>$row['attendance_duration']));
	}
}

echo json_encode($response);

?>