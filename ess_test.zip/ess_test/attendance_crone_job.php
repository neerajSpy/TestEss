<?php
/**
 * Created by PhpStorm.
 * User: HP
 * Date: 8/14/2018
 * Time: 11:54 AM
 */
include "config/config.php";

define("WEEKDAY", "weekday");
define("WEEKEND", "weekend");
define("HOLIDAY", "holiday");

$current_date = $_POST['current_date'];

//SELECT `id`, `Date`, `Day`, `State`, `Occasion` FROM `holiday_calendar` WHERE 1
//$current_date = getAppliedDate();

$last_insert_id = 0;

$result = $con->query("SELECT * from `holiday_calendar` where `State` != 'weekday' AND `Date` = '$current_date'");
if ($result->num_rows > 0) {
    if ($row = $result->fetch_array()) {
        $holiday_description = $row['Occasion'];
        $attendance = $row['State'];

        $user_id_result = $con->query("SELECT * from `user` ORDER  BY `id` ASC");
        if ($user_id_result->num_rows > 0) {
            while ($user_row = $user_id_result->fetch_array()) {
                $user_id = $user_row['id'];

                //SELECT `id`, `user_id`, `date`, `update_date`, `attendance`, `hrs`, `punch_in`, `punch_out`, `manual_punch_in`,
                // `manual_punchout`, `manual_punch_in_sys_time`, `manual_punch_out_sys_time`, `punch_in_photo_path`, `punch_out_photo_path`,
                // `punch_in_address`, `punch_in_location`, `punch_out_address`, `punch_out_location`, `summery`, `status` FROM `attendance`
                // WHERE 1

                //echo "attendance ".$attendance." user id ".$user_id."  Occasion ".$holiday_description."\n";

                $check_query_result = $con->query("SELECT * from `attendance` where `user_id` = '$user_id' AND `date` = '$current_date'");
                if ($check_query_result->num_rows < 1) {
                    $insert_attendance_query = "INSERT INTO `attendance` (`user_id`,`date`,`attendance`,`summery`) VALUES ('$user_id','$current_date','$attendance','$holiday_description')";
                    if ($con->query($insert_attendance_query) === TRUE) {
                        $last_insert_id = $con->insert_id;
                        echo " last insert id ".$last_insert_id." user id ".$user_id."\n";
                    }
                }else{

                    $update_attendance = $con->query("UPDATE `attendance` set `attendance` = '$attendance', `summery` = '$holiday_description' where `user_id` = '$user_id' AND `date` = '$current_date'");
                    $last_insert_id = $con->affected_rows;

                    echo " last update id ".$last_insert_id." user id ".$user_id."\n";
                }
            }
        }
    }
} else {

    //SELECT `id`, `leave_request_id`, `user_id`, `leave_date`, `length_hours`, `length_days`, `duration_type`, `leave_status_id`,
    // `comments`, `leave_type_id`, `start_time`, `end_time`, `date_applied`, `applied_by_id`, `status_date`, `status_by_id`
    // FROM `user_leaves` WHERE 1
    $leave_approve_id =  /*getLeaveApproveId($con)*/
        '4';
    $leave_result = $con->query("SELECT * from `user_leaves` where `leave_date` = '$current_date' AND `leave_status_id` = '$leave_approve_id'");
    if ($leave_result->num_rows > 0) {
        while ($leave_row = $leave_result->fetch_array()) {
            $user_id = $leave_row['user_id'];
            $duration_type = $leave_row['duration_type'];
            $duration_value = getDurationValue($con, $duration_type);
            echo "duration type value " . $duration_value . " user_id " . $user_id . "\n";
            $insert_attendance_query = "INSERT INTO `attendance` (`user_id`,`date`,`attendance`,`summery`) VALUES ('$user_id','$current_date','$duration_value','Leave')";
            if ($con->query($insert_attendance_query) === TRUE) {
                $last_insert_id = $con->insert_id;
            }

            $check_query_result = $con->query("SELECT * from `attendance` where `user_id` = '$user_id' AND `date` = '$current_date'");
            if ($check_query_result->num_rows < 1) {
                $insert_attendance_query = "INSERT INTO `attendance` (`user_id`,`date`,`attendance`,`summery`) VALUES ('$user_id','$current_date','$duration_value','Leave')";
                if ($con->query($insert_attendance_query) === TRUE) {
                    $last_insert_id = $con->insert_id;
                    echo " last leave insert id ".$last_insert_id." user id ".$user_id."\n";
                }
            }else{

                $update_attendance = $con->query("UPDATE `attendance` set `attendance` = '$duration_value', `summery` = 'leave' where `user_id` = '$user_id' AND `date` = '$current_date'");
                $last_insert_id = $con->affected_rows;

                echo " last leave update id ".$last_insert_id." user id ".$user_id."\n";
            }

        }

    }

}


function getDurationValue($con, $duration_type)
{
    //SELECT `id`, `name`, `value` FROM `leave_shift` WHERE 1
    $duration_type_value = "";

    $result = $con->query("SELECT * from `leave_shift` where `value` = '$duration_type'");
    if ($result->num_rows > 0) {
        if ($row = $result->fetch_array()) {
            $duration_type_value = $row['name'];
        }

    }
    return $duration_type_value;
}

function getLeaveApproveId($con)
{

}


function getAppliedDate()
{
    $now = new DateTime();
    return $now->format('Y-m-d H:i:s');
}

?>