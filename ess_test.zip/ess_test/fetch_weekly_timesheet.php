<?php
include "config/config.php";
$user_id = $_POST['user_id'];

$start_date = $_POST['start_date'];

$start_date = $_POST['start_date'];
$prev_date = date('Y-m-d', strtotime($start_date .' -7 day'));

echo "start_date ".$start_date." end Date ".$prev_date;



?>