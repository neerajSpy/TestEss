<?php
include "config/config.php";
date_default_timezone_set('Asia/Kolkata');

$user_id = $_POST['user_id'];
$address = $_POST['out_address'];
$location = $_POST['out_location'];
$status = $_POST['punch_status'];
$spent_time = $_POST['spent_time'];
$punch_out = $_POST['punch_out']; # [2018-05-12 hh:mm:ss]
$attendance = $_POST['attendance'];
$date_parts = preg_split('/\s+/', $punch_out);
$date = $date_parts[0];

//$photo_path = $_FILES['photo_path']['tmp_name'];

/*$extension = getFileExtension($_FILES['photo_path']['name']);
$file_name = $_FILES['photo_path']['name'];
$new_file_name =  $user_id.'_'.getFileName($file_name). '.' . $extension;
$filedest = dirname(__FILE__) .'/image/'. $new_file_name;*/


//SELECT `id`, `user_id`, `date`, `punch_in`, `punch_out`, `manual_punch_in`, `manual_punchout`, `manual_punch_in_sys_time`, `manual_punch_out_sys_time`, `punch_in_photo_path`, `punch_out_photo_path`, `punch_in_address`, `punch_in_location`, `punch_out_address`, `punch_out_location` FROM `attendance` WHERE 1

// 28.658231,77.2297909
$sql_query = "UPDATE `attendance` set  `attendance` = '$attendance',`punch_out` = '$punch_out', `attendance_duration` = '$spent_time', `punch_out_location`= '$location',`punch_out_address` = '$address', `status` = '$status' WHERE `date`= '$date' AND `user_id` = '$user_id'";



if ($con->query($sql_query) === TRUE) {
    $response['error'] = false;
    $response['message'] = "Successfully Saved";
}else{
    $response['error'] = true;
    $response['message'] = "Failed!";
}

echo json_encode($response);

function getFileExtension($file){

  $path_parts = pathinfo($file);
    //get extension
  return $path_parts['extension'];
}


function getFileName($file){

  $path_parts = pathinfo($file);
  return $path_parts['filename'];
}
?>
