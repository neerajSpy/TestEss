<?php
include "config/config.php";
date_default_timezone_set('Asia/Kolkata');


$start_position = $_POST['start_position'];
$access_control_id = $_POST['access_control_id'];
$user_id = $_POST['user_id'];
$action = $_POST['action'];

//SELECT `id`, `Project Name`, `Description`, `Billing Type`, `Project Cost`, `Customer Name`, `cust_id`, `Currency Code`, `project_type_id`, `Budget Type`, `Budget Amount`, `Project Budget Hours`, `CF.Estimated Days`, `tl_ts_approver_id`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `created_by`, `modified_by`, `is_active`, `created_date`, `modified_date`, `project_status` FROM `master_zoho_project` WHERE 1

//
$response = array();
$sql_query = "";
if (strtolower(trim($action)) == "submit") {
	$sql_query = "SELECT * FROM `temp_project` WHERE `is_active` = '0' AND `created_by` = '$user_id' ORDER BY `Project Name` ASC";
}else if (strtolower(trim($action)) == "approve") {
	$sql_query = "SELECT * FROM `temp_project` WHERE `is_active` = '0' ORDER BY `Project Name` ASC";
}else if (strtolower(trim($action)) == "add") {
	$sql_query = "SELECT * FROM `master_zoho_project` ORDER BY `Project Name` ASC ";
} 

$result = $con->query($sql_query);
if ($result->num_rows >0) {
	while ($row = $result->fetch_array()) {

		$project_type = getProjectType($con,$row['project_type_id']);
		$userName = getUserName($con,$row['created_by']);
		array_push($response, array("id"=>$row['id'],"project_name"=>$row['Project Name'],"project_type_id"=>$row['project_type_id'],"project_type"=>$project_type,"description"=>$row['Description'],"billing_ype"=>$row['Billing Type'],"project_cost"=>$row['Project Cost'],"customer_name"=>$row['Customer Name'],"cust_id"=>$row['cust_id'],"client_name"=>$row['client_name'],"currency_code"=>$row['Currency Code'],"budget_type"=>$row['Budget Type'],"budget_amount"=>$row['Budget Amount'],"project_budget_hours"=>$row['Project Budget Hours'],"estimated_days"=>$row['CF.Estimated Days'],"tl_ts_approver_id"=>$row['tl_ts_approver_id'],"location"=>$row['location'],"address"=>$row['address'],"district"=>$row['district'],"country"=>$row['country'],"state"=>$row['state'],"is_job_allocation_sheet"=>$row['is_job_allocation_sheet'],"is_system_backup"=>$row['is_system_backup'],"planned_start_date"=>$row['planned_start_date'],"planned_end_date"=>$row['planned_end_date'],"created_by"=>$row['created_by'],"name"=>$userName,"modified_by"=>$row['modified_by']));
	}
}

function getProjectType($con,$project_type_id){
	$project_type = "";
	$result = $con->query("SELECT `type` from `project_type` WHERE `id` = '$project_type_id' ");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_assoc()) {
			$project_type = $row['type'];
		}
	}
	return $project_type;
}

function getUserName($con,$user_id){
	$name = "";
	$result = $con->query("SELECT * from `user` WHERE `id` = '$user_id'");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_assoc()) {
			$name = $row['name'];
		}
	}
	return $name;
}

echo json_encode($response);
?>
