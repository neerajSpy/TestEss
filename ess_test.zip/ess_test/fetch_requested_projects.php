<?php
include "config/config.php";
date_default_timezone_set('Asia/Kolkata');

$project_id = $_POST['project_id'];
$user_id = $_POST['user_id'];


$response = array();

$now = new DateTime();
$current_date =  $now->format('Y-m-d H:i:s');

//SELECT `id`, `project_id`, `created_by_id`, `created_date`, `modified_by_id`, `modified_date`, `is_active` FROM `request_assign_project` WHERE 1

$result = $con->query("SELECT rap.*, u.`name`, mzp.`Project Name` from `request_assign_project` as rap JOIN `user` u ON rap.`created_by_id` = u.`id` JOIN `master_zoho_project` as mzp on mzp.`id` = rap.`project_id` WHERE rap.`is_active` = '1' ORDER BY rap.`created_date` DESC");

if ($result->num_rows >0) {
    while ($row = $result->fetch_assoc()) {
        array_push($response,array("id"=>$row['id'],"project_id"=>$row['project_id'],"project_name"=>$row['Project Name'],"created_by_id"=>$row['created_by_id'],"created_by"=>$row['name']));
    }
}

echo json_encode($response);

?>