<?php
include "config/config.php";
date_default_timezone_set('Asia/Kolkata');

$user_id = $_POST['user_id'];
$project_id = $_POST['project_id'];
$access_control_id = $_POST['access_control_id'];
$customer_id = $_POST['customer_id'];
$customer_name = $_POST['customer_name'];
$project_name = $_POST['project_name'];
$project_type_id = $_POST['project_type_id'];
$description = $_POST['description'];
$estimated_days = $_POST['estimated_days'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$action = $_POST['action'];
$state = $_POST['state'];
$country = $_POST['country'];
$location = $_POST['location'];
$address = $_POST['address'];
$district = $_POST['district'];
$client_name = $_POST['client_name'];

$date = new DateTime($end_date);
$now = new DateTime($start_date);

$days = $date->diff($now)->format("%d");
$currency_code = "INR";
$budget_type = "No Budget";

$response = array();

$now = new DateTime();
$current_date =  $now->format('Y-m-d H:i:s');


$last_insert_id = -1;

$emailResponse = array('user_id' =>$user_id,'customer_name'=>$customer_name,'project_name' =>$project_name,'project_type_id'=>$project_type_id,"billing_type"=>$billing_type,"budget_amount"=>"0",'project_budget_hours'=>"0",'start_date'=>$start_date,'end_date'=>$end_date,'description'=>$description);

//SELECT `id`, `Project Name`, `Description`, `Billing Type`, `Project Cost`, `Customer Name`, `cust_id`,
// `Currency Code`, `project_type_id`, `Budget Type`, `Budget Amount`, `Project Budget Hours`, `CF.Estimated Days`,
// `tl_ts_approver_id`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `created_by`,
// `modified_by`, `is_active`, `created_date`, `modified_date`, `project_status` FROM `master_zoho_project` WHERE 1

if ($project_id == "0" || $project_id == ""){

	$last_insert_id = 0;

	$result = $con->query("SELECT * From `temp_project` WHERE `Project Name` ='$project_name' AND `project_type_id` = '$project_type_id'");
	if ($result->num_rows < 1) {
		
		//echo "inside temp\n";
		$insert_query = "INSERT INTO `temp_project` (`Project Name`,`address`,`district`,`location`, `Description`,`client_name`,`Customer Name`, `cust_id`,`Currency Code`,`project_type_id`,`CF.Estimated Days`,`planned_start_date`,`planned_end_date`,`created_by`,`created_date`,`country`,`state`) VALUES ('$project_name','$address','$district','$location', '$description','$client_name','$customer_name','$customer_id','$currency_code','$project_type_id','$estimated_days','$start_date','$end_date','$user_id','$current_date','$country','$state')";

		if ($con->query($insert_query) === TRUE) {
			$last_insert_id = $con->insert_id;
			$project_id = $last_insert_id;

			//echo "inserted ".$project_id;
		}

	}

}else{

	$last_insert_id = 0;


	$result = $con->query("UPDATE `temp_project` set `Project Name` = '$project_name', `Description`= '$description',`client_name` = '$client_name',`Customer Name`= '$customer_name',`cust_id` = '$customer_id',`Currency Code` = 'INR',`project_type_id`= '$project_type_id',`CF.Estimated Days` = '$estimated_days',`planned_start_date`= '$start_date',`planned_end_date`= '$end_date',`modified_by`= '$user_id',`modified_date`= '$current_date',`location` ='$location',`district` = '$district',`address` = '$address',`country`='$country',`state`='$state' WHERE `id` = '$project_id'");

	if ($con->affected_rows >0) {
		$last_insert_id = 1;

		//echo "update ".$last_insert_id;
	}
}	

if ($last_insert_id >0) {
	$response['id'] = $project_id;
	$response['error'] = false;
	$response['message'] = "Successfully Saved.";
		sendNotification($con,$user_id,$project_name);
		sendEmail($con,$emailResponse);
	
}else if ($last_insert_id == -1){
	$response['id'] = "0";
	$response['error'] = true;
	$response['message'] = "Project not saved. Duplicate project or project type";
}else {
	$response['id'] = 0;
	$response['error'] = true;
	$response['message'] = "Project not saved.";
}


echo json_encode($response);

function getUserData($con,$user_id){
	$userArray = array();
	$result = $con->query("SELECT * from `user` WHERE `id` = '$user_id'");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_assoc()) {
			$userArray['name'] = $row['name'];
			$userId = $row['id'];
		}
	}
	return $userArray;
}

function sendNotification($con,$user_id,$project_name){
	$userData = getUserData($con,$user_id);
	$token_query = "SELECT uft.`token`  from `user` as u JOIN `user_fcm_token` as uft on u.`id` = uft.`user_id` WHERE u.`access_control_id` = 2";
	$ss= $con->query($token_query);

	$ch = curl_init("https://fcm.googleapis.com/fcm/send");
	$serverKey = "AIzaSyDJ0MiSBWBsQN5y-ybhWr2GNGFzTPsSfFQ";

	$notificationArr = array();
	array_push($notificationArr,array("project_name"=>$project_name,"user_name"=>$userData['name']));

	$notification = array("body" => array("module"=>"Request Add Project","json_response"=>$notificationArr));

	while($r= ($ss->fetch_array())) {

		$f = $r['token'];
		$arrayToSend = array('to' => $f, 'data' => $notification);

		$json = json_encode($arrayToSend);
      // echo $json;
		$headers = array();
		$headers[] = "Content-Type: application/json";
		$headers[] = "Authorization: key= $serverKey";

		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
		curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$result = curl_exec($ch);
		if($result === false)
		{
            //echo  'Curl failed ' . curl_error($ch);
		}

	}
	curl_close($ch);
}


function getUserArray($con,$user_id){
	$userArray = array();
	$result = $con->query("SELECT * from `user` WHERE `id` = '$user_id'");
	if($row = $result->fetch_array()){
		$userArray = $row;
	}

	return $userArray;
}

function getProjectType($con,$type_id){
	$type = "";
	$result = $con->query("SELECT * From `project_type` WHERE `id` = '$type_id'");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_assoc()) {
			$type = $row['type'];
		}
	}
	return $type;
}

function sendEmail($con,$emailResponse){

	$project_type = getProjectType($con,$emailResponse['project_type_id']);
	$userArray = getUserArray($con,$emailResponse['user_id']);

$To =  "ranju.kumari@technitab.in, kavinder.kohli@technitab.com"; // note the comma
$from = $userArray['email'];

$subject = 'Add project Request : '.$userArray['name'];
$message = '
<html>

<body>
Dear Admin,
<p>Please approve the following project request submitted by '.$userArray['name'].' as per information below </p>
Customer Name : '.$emailResponse['customer_name'].'<br>
Project Name : '.$emailResponse['project_name'].'<br>
Project Type : '.$project_type.'<br>
Billing Type : '.$emailResponse['billing_type'].'<br>
Budget Amount : '.$emailResponse['budget_amount'].'<br>
Project Budget hour : '.$emailResponse['project_budget_hours'].'<br>
Start date : '.$emailResponse['start_date'].'<br>
End date : '.$emailResponse['end_date'].'<br>
Description : '.$emailResponse['description'].'<br>

<p></p>
Regards.<br>
Ess App
</body>
</html>
';

// To send HTML mail, the Content-type header must be set
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-type: text/html; charset=iso-8859-1';

// Additional headers
$headers[] = 'To: '.$To;
$headers[] = 'From: '.$userArray['name'].' '.$userArray['email'];
$headers[] = 'Bcc: neeraj.kumar@technitab.in';

mail($To, $subject, $message, implode("\r\n", $headers));

}



?>