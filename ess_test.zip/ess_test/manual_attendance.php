<?php
date_default_timezone_set('Asia/Kolkata');
include "config/config.php";

$date = $_POST['date'];
$punch_in = $_POST['punch_in'];
$user_id = $_POST['user_id'];
$punch_out = $_POST['punch_out'];
$attendance = $_POST['attendance'];
$attendance_duration = $_POST['attendance_duration'];
$remark = $_POST['remark'];


$response = array();

$now = new DateTime();
$current_date =  $now->format('Y-m-d H:i:s');

//SELECT `id`, `user_id`, `date`, `update_date`, `attendance`, `attendance_duration`, `timesheet_duration`, `punch_in`, `punch_out`, `manual_punch_in`, `manual_punchout`, `manual_punch_in_sys_time`, `manual_punch_out_sys_time`, `punch_in_photo_path`, `punch_out_photo_path`, `punch_in_address`, `punch_in_location`, `punch_out_address`, `punch_out_location`, `summery`, `status`, `is_active` FROM `attendance` WHERE 1

$last_insert_id = -1;
$isWeekDay = checkHolidayCalender($con,$date);

/* isWeekDay 1 means weekend else holiday or weekend */
if ($isWeekDay >0) {
$last_insert_id = -2;
$attendanceResult = $con->query("SELECT * from `attendance` WHERE `user_id` = '$user_id' AND `date` = '$date' AND `status` = '2'");

if ($attendanceResult->num_rows <1) {
$punchInResult = $con->query("SELECT * from `attendance` WHERE `user_id` = '$user_id' AND `date` = '$date'");
if ($punchInResult->num_rows < 1) {
$query = "INSERT INTO `attendance` (`date`,`attendance`,`attendance_duration`,`manual_punch_in`,`manual_punchout`,`manual_punch_out_sys_time`,`manual_punch_in_sys_time`,`user_id`,`status`,`remark`) VALUES('$date','$attendance','$attendance_duration','$punch_in','$punch_out','$current_date','$current_date','$user_id','2','$remark')";

if ($con->query($query) === TRUE) {
	$last_insert_id = $con->insert_id;
}
}else {
	$updateResult = $con->query("UPDATE `attendance` set `date` = '$date',`attendance_duration` = '$attendance_duration',`punch_in` = '$punch_in', `punch_out` = '$punch_out' , `attendance` ='$attendance',`remark`='$remark' WHERE `date` ='$date' AND `user_id` = '$user_id'");

	if ($updateResult === TRUE) {
		$last_insert_id = $con->affected_rows;
	}
}

}
}


if ($last_insert_id == -1) {
	$response['error'] = true;
	$response['message'] = $date.' is not weekday';
}else if($last_insert_id == -2){
    $response['error'] = true;
	$response['message'] = "Attendance already filled on this date.";
}else if ($last_insert_id > 0 ){
	$response['error'] = false;
	$response['message'] = "Attendance request successfully saved.";
	sendNotification($con,$user_id,$date);
}else{
	$response['error'] = true;
	$response['message'] = "Attendance has not saved.";
}

echo json_encode($response);


function checkHolidayCalender($con,$date){
	// SELECT `id`, `Date`, `Day`, `State`, `Occasion` FROM `holiday_calendar` WHERE 1
	$result = $con->query("SELECT * from `holiday_calendar` WHERE `Date` = '$date' AND `State` = 'weekday'");
	return $result->num_rows;
}


function getUserData($con,$user_id){
	$user_name = "";
	$result = $con->query("SELECT * from `user` WHERE `id` = '$user_id'");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_assoc()) {
			$user_name = $row['name'];
		}
	}
	return $user_name;
}



function sendNotification($con,$user_id,$date,$remark){
	$user_name = getUserData($con,$user_id);
	$token_query = "SELECT uft.`token`  from `user` as u JOIN `user_fcm_token` as uft on u.`id` = uft.`user_id` WHERE u.`access_control_id` = 2";
	$ss= $con->query($token_query);

	$ch = curl_init("https://fcm.googleapis.com/fcm/send");
    $serverKey = "AIzaSyDJ0MiSBWBsQN5y-ybhWr2GNGFzTPsSfFQ";

	$notificationArr = array();
	array_push($notificationArr,array("date"=>$date,"user_name"=>$user_name,"remark"=>$remark));

	$notification = array("body" => array("module"=>"Attendance Request","json_response"=>$notificationArr));

	while($r= ($ss->fetch_array())) {

		$f = $r['token'];
		$arrayToSend = array('to' => $f, 'data' => $notification);

		$json = json_encode($arrayToSend);
      // echo $json;
		$headers = array();
		$headers[] = "Content-Type: application/json";
		$headers[] = "Authorization: key= $serverKey";

		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
		curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$result = curl_exec($ch);
		if($result === false)
		{
            //echo  'Curl failed ' . curl_error($ch);
		}

	}
	curl_close($ch);
}



?>