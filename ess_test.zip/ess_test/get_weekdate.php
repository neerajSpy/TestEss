<?php
/**
 * Created by PhpStorm.
 * User: HP
 * Date: 8/13/2018
 * Time: 12:05 PM
 */


$signupweek= $_POST['date'];
$name = $_POST['name'];

echo "name :".$name;
/*start day*/
for($i = 0; $i <7 ; $i++)
{
    $date = date('Y-m-d', strtotime("-".$i."days", strtotime($signupweek)));
    $dayName = date('D', strtotime($date));
    if($dayName == "Sun")
    {
        echo "start day is ". $date."\n";
    }
}
/*end day*/
for($i = 0; $i <7 ; $i++)
{
    $date = date('Y-m-d', strtotime("+".$i."days", strtotime($signupweek)));
    $dayName = date('D', strtotime($date));
    if($dayName == "Sat")
    {
        echo "end day is ". $date."\n";
    }
}

?>