<?php
include "config/config.php";

$employee_id = $_POST['employee_id'];
$month = $_POST['month'];
$year = $_POST['year'];


$response = array();


//SELECT `id`, `employee_id`, `date`, `update_date`, `attendance`, `hrs`, `punch_in`, `punch_out`, `manual_punch_in`, `manual_punchout`, `manual_punch_in_sys_time`, `manual_punch_out_sys_time`, `punch_in_photo_path`, `punch_out_photo_path`, `punch_in_address`, `punch_in_location`, `punch_out_address`, `punch_out_location`, `summery` FROM `attendance` WHERE 1

$sql_query = "SELECT * from `attendance` WHERE MONTH(`date`) = '$month' AND YEAR(`date`) = '$year' AND `employee_id` = '$employee_id' ORDER By `date` ASC";

$result = $con->query($sql_query);
 if($result->num_rows >0) {
  while ($row = $result->fetch_array()) {

    $punch_in = $row['punch_in'];
    $punch_out = $row['punch_out'];

    $manual_punch_in = $row['manual_punch_in'];
    $manual_punchout = $row['manual_punchout'];
    if ($punch_in == "") {
      $punch_in = "0";
      $punch_out = "0";
    }

    if ($manual_punch_in == "") {
      $manual_punch_in = "0";
      $manual_punchout = "0";
    }
    array_push($response,array("date"=>$row['date'],"attendanceType"=>$row['attendance'],"hrs"=>$row['hrs'],"punch_in"=>$punch_in,"punch_out"=>$punch_out,"manual_punch_in"=>$manual_punch_in,"manual_punch_out"=>$manual_punchout,"summery"=>$row['summery']));

  }
}

echo json_encode($response);
?>
