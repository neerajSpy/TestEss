<?php
include "config/config.php";

date_default_timezone_set('Asia/Kolkata');

$tec_id = $_POST['tec_id'];
$role_id = $_POST['role_id'];
$user_id = $_POST['user_id'];
$status = $_POST['status'];
$project_name = $_POST['project_name'];
$created_by_id = $_POST['created_by_id'];
$remark = $_POST['remark'];

$current_date = date("Y-m-d h:m:s");
$request_date = date("Y-m-d");

$response = array();
$insert_id = 0;
$query = "INSERT into `emp_tec_log` (`tec_id`,`status`,`comment`,`created_date`,`created_by_id`) VALUES ('$tec_id','$status','$remark','$request_date','$user_id')";



if ($con->query($query) === TRUE) {
		$insert_id = $con->insert_id;
		$tec_query = "";
    	if (strtolower($status) == 'draft' || strtolower($status) == 'submit') {
    		$tec_query = "UPDATE `emp_main_tec` set `status`= '$status',`total_amount` = '0',`remark` = '$remark', `modified_date` = '$request_date', `modified_by_id` = '$user_id' WHERE `id` = '$tec_id'";
    	}else {
    		$tec_query = "UPDATE `emp_main_tec` set `status`= '$status',`remark` = '$remark', `modified_date` = '$request_date', `modified_by_id` = '$user_id' WHERE `id` = '$tec_id'";
    	}

    	$result = $con->query($tec_query);

		$tecData = getTECIdData($con,$tec_id);
		sendNotification($con,$tecData,$status,$created_by_id,$project_name);
	}


if ($insert_id>0) {
	$response['error'] = false;
	$response['message'] = "Status changed";
}else{
	$response['error'] = TRUE;
	$response['message'] = "TCE not saved";
}


echo json_encode($response);

function getTECIdData($con,$tec_id){
	$arr = array();
	$result = $con->query("SELECT * from `emp_main_tec` WHERE `id` = '$tec_id'");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_assoc()) {
			$arr = $row;
		}
	}
	return $arr;
}


function sendNotification($con,$tecData,$status,$created_by_id,$project_name){
	  $notificationStatus = "";
	  if ($status == "draft") {
	  	$notificationStatus = "Please recheck tec.";
	  }else if ($status == "submit") {
	  	$notificationStatus = "submit for checking";
	  }else if ($status == "open"){
	  	$notificationStatus = "tec approve";
	  }else {
	  	$notificationStatus =  "tec payment done";
	  }

	$ss= $con->query("SELECT `token`  from `user_fcm_token` WHERE `user_id` = '$created_by_id'");  

    $ch = curl_init("https://fcm.googleapis.com/fcm/send");

    $serverKey = "AIzaSyDJ0MiSBWBsQN5y-ybhWr2GNGFzTPsSfFQ";

    $notificationArr = array();
    array_push($notificationArr,array("status"=>$notificationStatus,"project_name"=>$project_name,"request_date"=>$tecData['clim_start_date']));

    $notification = array("body" => array("module"=>"tec_update","json_response"=>$notificationArr));

    while($r= ($ss->fetch_array())) {
        
        $f = $r['token'];
        $arrayToSend = array('to' => $f, 'data' => $notification);

        $json = json_encode($arrayToSend);
      // echo $json;
        $headers = array();
        $headers[] = "Content-Type: application/json";
        $headers[] = "Authorization: key= $serverKey";
        
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
        curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($ch);
        if($result === false)
        {
            //echo  'Curl failed ' . curl_error($ch);
        }

    }
    curl_close($ch);

	    
	}


?>