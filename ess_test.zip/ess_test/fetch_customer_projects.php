<?php
/**
 * Created by PhpStorm.
 * User: HP
 * Date: 8/24/2018
 * Time: 2:14 PM
 */

// SELECt DISTINCT(`project_id`) from `activity_user` WHERE `user_id` = '1' ORDER BY `created_date` DESC

include "config/config.php";

$customer_id = $_POST['customer_id'];
$response = array();

$project_result = $con->query("SELECT * from `master_zoho_project` WHERE `cust_id` = '$customer_id'");
if ($project_result->num_rows > 0) {
    while ($project_row = $project_result->fetch_assoc()) {
        $project_type_id = $project_row['project_type_id'];
        $project_type = getProjectType($con, $project_type_id);
        array_push($response, array("project_name" => $project_row['Project Name'], "project_type" => $project_type));
    }
}

echo json_encode($response);

function getProjectType($con, $project_type_id)
{
    $project_type = "";
    $result = $con->query("SELECT * from `project_type` where `id` = '$project_type_id'");
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $project_type = $row['type'];
        }
    }
    return $project_type;
}