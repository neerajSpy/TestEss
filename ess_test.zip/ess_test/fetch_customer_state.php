<?php
date_default_timezone_set('Asia/Kolkata');
include "config/config.php";

$state = $_POST['state'];
$response = array();

$result = $con->query("SELECT * from `master_zoho_customer` where LOWER(`Place of Contact With State Code`) LIKE LOWER('%$state%')");

if ($result->num_rows >0) {
	while ($row = $result->fetch_assoc()) {
		array_push($response,array("id"=>$row['id'],"customer_name"=>$row['Display Name']));
	}
}

echo json_encode($response);

?>