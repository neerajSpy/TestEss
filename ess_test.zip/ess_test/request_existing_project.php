<?php
include "config/config.php";
date_default_timezone_set('Asia/Kolkata');

$project_id = $_POST['project_id'];
$user_id = $_POST['user_id'];


$response = array();

$now = new DateTime();
$current_date =  $now->format('Y-m-d H:i:s');

//SELECT `id`, `project_id`, `created_by_id`, `created_date`, `modified_by_id`, `modified_date`, `is_active` FROM `request_assign_project` WHERE 1

$result = $con->query("INSERT INTO `request_assign_project` (`project_id`, `created_by_id`,`created_date`) VALUES ('$project_id','$user_id','$current_date')");

if ($result === TRUE) {
    $response['error'] = false;
    $response['message'] = "Project Request Saved.";
    $project_name = getProjectName($con,$project_id);
    sendNotification($con,$created_by_id,$project_name);
}else{
    $response['error'] = false;
    $response['message'] = "Project Request not saved.";
}

echo json_encode($response);



function getProjectName($con,$project_id){
    $project_name = "";
    $result = $con->query("SELECT * from `master_zoho_project` WHERE `id` = '$project_id'");

    if ($result->num_rows >0) {
        if ($row = $result->fetch_assoc()) {
            $project_name = $row['Project Name'];
        }
    }
    return $project_name;
}


function sendNotification($con,$user_id,$project_name){
    $userName = getUserName($con,$user_id);
    $token_query = "SELECT uft.`token`  from `user` as u JOIN `user_fcm_token` as uft on u.`id` = uft.`user_id` WHERE u.`access_control_id` = 2";
    $ss= $con->query($token_query);

    $ch = curl_init("https://fcm.googleapis.com/fcm/send");
    $serverKey = "AIzaSyDJ0MiSBWBsQN5y-ybhWr2GNGFzTPsSfFQ";

    $notificationArr = array();
    array_push($notificationArr,array("project_name"=>$project_name,"user_name"=>$userName));

    $notification = array("body" => array("module"=>"Request Existing Project","json_response"=>$notificationArr));

    while($r= ($ss->fetch_array())) {

        $f = $r['token'];
        $arrayToSend = array('to' => $f, 'data' => $notification);

        $json = json_encode($arrayToSend);
      // echo $json;
        $headers = array();
        $headers[] = "Content-Type: application/json";
        $headers[] = "Authorization: key= $serverKey";

        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
        curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($ch);
        if($result === false)
        {
            //echo  'Curl failed ' . curl_error($ch);
        }

    }
    curl_close($ch);
}


function getUserName($con,$user_id){
    $userName = "";
    $result = $con->query("SELECT * from `user` WHERE `id` = '$user_id'");
    if ($result->num_rows >0) {
       if($row = $result->fetch_array()){
        $userName = $row['name'];
       }
    }
    return $userName;
}


?>