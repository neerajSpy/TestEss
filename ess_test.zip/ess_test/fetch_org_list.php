<?php
include "config/config.php";

$position = $_POST['position'];
$role_id = $_POST['role_id'];
$related_table = $_POST['related_table'];

if (strlen($related_table) <1) {
	$related_table = getRelatedTable($con,$role_id);
}

//echo "max position ".$maxPosition."\n";

$type_id = getTypeId($con,$role_id,$related_table);
$type = getOrgType($con,$type_id);
//SELECT `id`, `type_id`, `asset_type`, `description`, `make`, `model`, `serial_number`, `supplier`, `purchase_order_number`, `invoice_date`, `warranty_period`, `delivery_date`, `supplier_invoice_number`, `unit_price`, `tax_percentage`, `Tax_value`, `shipping_tax`, `shipping_charge`, `vat_or_gst_percentage`, `vat_or_gst_value`, `total_cost_asset`, `value_of_asset`, `class_of_assets`, `useful_life`, `depreciation_allowance`, `disposal_date`, `method_disposal`, `sale_price`, `accouunts_ref`, `attachment_path`, `zoho_category` FROM `fix_assests` WHERE 1

$response = array();

$sub_result = $con->query("SELECT `id`, `primary_org`,`automation_org`, `control_relay_org`, `it_admin_org`, `office_guest_house_org`,`fix_asset` from `org_unit_fix_assets` WHERE `fix_asset` != 'Books'");

		//echo "id ".$row['id']." type id ".$id." user type ".$$type_id."\n";
if ($sub_result->num_rows >0) {
if (($subRow = $sub_result->fetch_array()) /*&& $maxPosition >= $position*/)  {

				//print_r($subRow)."\n";
	if ($subRow['primary_org'] == 1 || $subRow['office_guest_house_org'] == 1 || $subRow[$type] == 1) {
		array_push($response,$subRow);
	}
}


echo json_encode($response);


function getTypeId($con,$role_id,$related_table){
	$id = 0;
	$result = $con->query("SELECT * from $related_table WHERE `id` = '$role_id'");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_assoc()) {
			$id = $row['org_unit_id'];
		}
	}
	return $id;
}

function getOrgType($con,$org_unit_id){
	$type = "";
	$result = $con->query("SELECT * from `organisation_unit_type` WHERE `id` = '$org_unit_id'");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_assoc()) {
			$type = $row['name'];
		}
	}
	return $type;
}

function getRelatedTable($con,$role_id){
	$tableName = "";
	$result = $con->query("SELECT * FROM `user` WHERE `role_id` = '$role_id'");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_array()) {
			$tableName = $row['related_table'];    
		}

	}
	return $tableName;
}


?>