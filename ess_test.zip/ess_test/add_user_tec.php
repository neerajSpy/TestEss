<?php
include "config/config.php";

date_default_timezone_set('Asia/Kolkata');

$tec_id = $_POST['tec_id'];
$role_id = $_POST['role_id'];
$project_id = $_POST['project_id'];
$current_date = date("Y-m-d h:m:s");
$request_date = date("Y-m-d");

$response = array();

$result = $con->query("SELECT * from `emp_main_tec` WHERE `project_id` = '$project_id' AND `id` = '$tec_id' AND `role_id` = '$role_id'");

if ($result->num_rows >0) {
	$response['error'] = false;
	$response['message'] = "Successfully TEC Saved";
	sendNotification($con,$request_date,$role_id);
}else {
	$response['error'] = true;
	$response['message'] = "TEC not saved";
}


echo json_encode($response);

function getUserData($con,$role_id){
	$userArray = array();
	$result = $con->query("SELECT * from `user` WHERE `role_id` = '$role_id'");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_assoc()) {
			$userArray['name'] = $row['name'];
			$userId = $row['id'];
		}
	}
	return $userArray;
}


function sendNotification($con,$request_date,$role_id){
	$userData = getUserData($con,$role_id);
	
	$ss= $con->query("SELECT uft.`token`  from `user` as u JOIN `user_fcm_token` as uft on u.`id` = uft.`user_id` WHERE u.`access_control_id` = 2");  

	$ch = curl_init("https://fcm.googleapis.com/fcm/send");

	$serverKey = "AIzaSyDJ0MiSBWBsQN5y-ybhWr2GNGFzTPsSfFQ";

	$notificationArr = array();
	array_push($notificationArr,array("bill_date"=>$request_date,"entry_category"=>"TEC","user_name"=>$userData['name']));

	$notification = array("body" => array("module"=>"tec","json_response"=>$notificationArr));

	while($r= ($ss->fetch_array())) {

		$f = $r['token'];
		$arrayToSend = array('to' => $f, 'data' => $notification);

		$json = json_encode($arrayToSend);
      // echo $json;
		$headers = array();
		$headers[] = "Content-Type: application/json";
		$headers[] = "Authorization: key= $serverKey";

		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
		curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$result = curl_exec($ch);
		if($result === false)
		{
            //echo  'Curl failed ' . curl_error($ch);
		}

	}
	curl_close($ch);


}


?>