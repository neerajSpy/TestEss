<?php
include "config/config.php";

$user_id = $_POST['user_id'];
$response = array();

$exist_response = array();
$non_exist_response = array();

$project_type_list = $con->query("SELECT DISTINCT(`project_id`) FROM `activity_user` WHERE `user_id` = '$user_id'");

if ($project_type_list->num_rows >0) {
    while ($row = $project_type_list->fetch_array()) {
        $projectId = $row['project_id'];
        array_push($response,getProjectName($con, $projectId));

    }
}

echo json_encode($response);

function getProjectName($con,$project_id){
    $response = array();
    $result = $con->query("SELECT * from `master_zoho_project` where  `id` = '$project_id'");

    if ($result->nom_rows >=0){
        if ($row = $result->fetch_array()){
             $response['id']=$row['id'];
             $response['project_name']=$row['Project Name'];
             $response['project_type_id']=$row['project_type_id'];
             $project_type = getProjectType($con,$row['project_type_id']);
             $response['project_type'] = $project_type;
             $response['project_type']=$project_type;
             $response['Description']=$row['Description'];
             $response['billing_ype']=$row['Billing Type'];
             $response['project_cost']=$row['Project Cost'];
             $customer_name = getCustomerName($con,$row['cust_id']);
             $response['customer_name']=$customer_name;
             $response['cust_id']=$row['cust_id'];
             $response['client_name']=$row['client_name'];
             $response['currency_code']=$row['Currency Code'];
             $response['budget_type']=$row['Budget Type'];
             $response['budget_amount']=$row['Budget Amount'];
             $response['project_budget_hours']=$row['Project Budget Hours'];
             $response['estimated_days']=$row['CF.Estimated Days'];
             $response['tl_ts_approver_id']=$row['tl_ts_approver_id'];
             $response['location']=$row['location'];
             $response['address']=$row['address'];
             $response['district']=$row['district'];
             $response['is_job_allocation_sheet']=$row['is_job_allocation_sheet'];
             $response['is_system_backup']=$row['is_system_backup'];
             $response['planned_start_date']=$row['planned_start_date'];
             $response['planned_end_date']=$row['planned_end_date'];
             $response['created_by']=$row['created_by'];
             $response['name']=$userName;
             $response['modified_by']=$row['modified_by'];

        }
    }
    return $response;
}


function getProjectType($con,$project_type_id){
    $project_type = "";
    $result = $con->query("SELECT `type` from `project_type` WHERE `id` = '$project_type_id' ");
    if ($result->num_rows >0) {
        if ($row = $result->fetch_assoc()) {
            $project_type = $row['type'];
        }
    }
    return $project_type;
}


function getCustomerName($con,$customerId){
    $customerName = "";

    $result = $con->query("SELECT * from `master_zoho_customer` where  `id` = '$customerId'");

    if ($result->nom_rows >=0){
        if ($row = $result->fetch_array()){
            $customerName = $row['Display Name'];
        }
    }
    return $customerName;
}




?>