<?php
include "config/config.php";

$position = $_POST['position'];
$role_id = $_POST['role_id'];
$related_table = $_POST['related_table'];

if (strlen($related_table) <1) {
	$related_table = getRelatedTable($con,$role_id);
}

$maxPosition = $position + 20;
//echo "max position ".$maxPosition."\n";

$type_id = getTypeId($con,$role_id,$related_table);
//SELECT `id`, `type_id`, `asset_type`, `description`, `make`, `model`, `serial_number`, `supplier`, `purchase_order_number`, `invoice_date`, `warranty_period`, `delivery_date`, `supplier_invoice_number`, `unit_price`, `tax_percentage`, `Tax_value`, `shipping_tax`, `shipping_charge`, `vat_or_gst_percentage`, `vat_or_gst_value`, `total_cost_asset`, `value_of_asset`, `class_of_assets`, `useful_life`, `depreciation_allowance`, `disposal_date`, `method_disposal`, `sale_price`, `accouunts_ref`, `attachment_path`, `zoho_category` FROM `fix_assests` WHERE 1

$response = array();

$result = $con->query("SELECT fa.* from `fix_assests` as fa JOIN `fix_asset_allocation` as faa on fa.`id` !=  faa.`fix_asset_id`  ORDER BY fa.`id` ASC");
/*echo "num ".$result->num_rows;*/
if ($result->num_rows >0) {
	while ($row = $result->fetch_assoc()) {
		$id = $row['type_id'];
		$sub_result = $con->query("SELECT `primary_org`,`automation_org`, `control_relay_org`, `it_admin_org`, `office_guest_house_org` from `org_unit_fix_assets` WHERE `id` = '$id'");

		//echo "id ".$row['id']." type id ".$id." user type ".$$type_id."\n";
		if ($sub_result->num_rows >0) {
			if (($subRow = $sub_result->fetch_array()) /*&& $maxPosition >= $position*/)  {
				
				//print_r($subRow)."\n";
				if ($subRow[0] == 1 || $subRow[4] == 1 || $subRow[$type_id-1] == 1) {
					$position ++;
		          array_push($response,$row);
				}
			}
		}
		
	}
}


function getTypeId($con,$role_id,$related_table){
	$id = 0;
	$result = $con->query("SELECT * from $related_table WHERE `id` = '$role_id'");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_assoc()) {
			$id = $row['org_unit_id'];
		}
	}
	return $id;
}


function getRelatedTable($con,$role_id){
    $tableName = "";
    $result = $con->query("SELECT * FROM `user` WHERE `role_id` = '$role_id'");
    if ($result->num_rows >0) {
        if ($row = $result->fetch_array()) {
        $tableName = $row['related_table'];    
        }
        
    }
    return $tableName;
}


echo json_encode($response);
?>