    <?php
       /**
     * Created by PhpStorm.
     * User: HP
     * Date: 8/20/2018
     * Time: 12:16 PM
     */

    include "config/config.php";
    date_default_timezone_set('Asia/Kolkata');

    //{"account_number":"fghhhfd","adhaar_number":"ddsff","bank_address":"vvhhhnb","bank_name":"741588","billing_address":"thanks so much for",
    //"billing_city":"thanks","billing_country":"djsk","billing_phone":"7664666343","billing_state":"thanks","billing_zipcode":"12282",
    //"contact":"7664666343","display_contact_name":"we the","email":"nk88337@gmail.com","first_name":"thanks","gst_num":"4677",
    //"gst_treatment":"Registered Business - Composition","id":0,"ifsc":"147788","last_name":"thanks",
    //"pan_number":"fddf","payment_term":"Net 15","place_of_supply":"Registered Business - Regular",
    //"service_tax_number":"ddgh","shipping_address":"thanks so much for","shipping_city":"thanks","shipping_country":"djsk",
    //"shipping_phone":"7664666343","shipping_state":"thanks","shipping_zipcode":"12282","tax_number":"fdv"}

    $vendor_json = json_decode($_POST['vendor_json']);
    $user_id = $_POST['user_id'];

  
    $id = $vendor_json->id;
    $first_name = $vendor_json->first_name;
    $last_name = $vendor_json->last_name;
    $company_name = $vendor_json->company_name;
    $email = $vendor_json->email;
    $contact = $vendor_json->contact;
    $gst_treatment = $vendor_json->gst_treatment;
    $gst_num = $vendor_json->gst_num;
    $place_of_supply = $vendor_json->place_of_supply;
    $payment_term = $vendor_json->payment_term;
    $billing_address = $vendor_json->billing_address;
    $district = $vendor_json->district;
    $billing_city = $vendor_json->billing_city;
    $billing_state = $vendor_json->billing_state;
    $billing_country = $vendor_json->billing_country;
    $billing_zipcode = $vendor_json->billing_zipcode;
    $billing_address = $vendor_json->billing_address;
    $billing_phone = $vendor_json->billing_phone;
    $shipping_city = $vendor_json->shipping_city;
    $shipping_state = $vendor_json->shipping_state;
    $shipping_zipcode = $vendor_json->shipping_zipcode;
    $shipping_country = $vendor_json->shipping_country;
    $shipping_address = $vendor_json->shipping_address;
    $shipping_phone = $vendor_json->shipping_phone;
    $pan_number = $vendor_json->pan_number;
    $service_tax_number = $vendor_json->service_tax_number;
    $tax_number = $vendor_json->tax_number;
    $adhaar_number = $vendor_json->adhaar_number;
    $bank_name = $vendor_json->bank_name;
    $bank_address = $vendor_json->bank_address;
    $ifsc = $vendor_json->ifsc;
    $vendor_type = $vendor_json->vendor_type;
    $account_number = $vendor_json->account_number;
    $bank_holder_name = $vendor_json->bank_holder_name;
    $createdById = $vendor_json->created_by_id;
    $rate = $vendor_json->rate;
    $voter_id = $vendor_json->voter_id;
    $payment_mode = $vendor_json->payment_mode;
    $bill_number = $vendor_json->bill_number;
    $bank_path = $vendor_json->bank_file;
    $bill_file_path = $vendor_json->bill_file;
    $id_proof_path = $vendor_json->id_proof_file;
    $gst_treatment = $vendor_json->gst_treatment;

    $current_date = getAppliedDate();

    $response = array();

    if($vendor_type == ""){
        $vendor_type = "Hotel";
    }


    if (strtolower($gst_treatment) == strtolower('registered business - regular')) {
        $gst_treatment = "business_gst";
    }else if (strtolower($gst_treatment) == strtolower("unregistered business")){
        $gst_treatment = "business_none";
    }
    


    if ($company_name == "") {
        $company_name = $first_name + " "+ $last_name;
    }


//SELECT `id`, `Created Time`, `Last Modified Time`, `Contact ID`, `Source of Supply`, `Contact Name`, `Display Name`, `Company Name`, `Salutation`, `First Name`, `Last Name`, `EmailID`, `Phone`, `MobilePhone`, `Skype Identity`, `Facebook`, `Twitter`, `Currency Code`, `Notes`, `Website`, `GST Treatment`, `GST Identification Number (GSTIN)`, `PAN Number`, `Payment Terms`, `Contact Address ID`, `Billing Attention`, `Billing Address`, `Billing Street2`, `Billing City`, `Billing State`, `Billing Country`, `Billing Code`, `Billing Phone`, `Billing Fax`, `Shipping Attention`, `Shipping Address`, `Shipping Street2`, `Shipping City`, `Shipping State`, `Shipping Country`, `Shipping Code`, `Shipping Phone`, `Shipping Fax`, `Source`, `Last Sync Time`, `Status`, `Vendor Payment`, `CF.Vendor type`, `CF.Payment Mode`, `CF.Contact ID`, `CF.Vendor District`, `CF.PAN No`, `CF.Service Tax No`, `CF.TAN No`, `CF.ADHAAR No`, `CF.Name of Vendor's Bank`, `CF.Bank's Address`, `CF.IFSC Code`, `CF.Bank a/c holder's name`, `CF.Bank Account number`, `CF.bill_file_path`, `CF.bill_number`, `CF.Voter ID`, `CF.Rate`, `CF.bank_file_path`, `CF.id_proof_file_path`, `created_by_id`, `created_date`, `modified_by_id`, `modified_date`, `temp_status` FROM `z_temp_temp_vendor` WHERE 1

    $last_insert_id = -1;

    $result = $con->query("SELECT * from `master_zoho_vendor` where `Display Name` = '$company_name' ");
    if ($result->num_rows < 1){
        $last_insert_id = 0;

        $insert_query = "INSERT INTO `master_zoho_vendor` (`Created Time`,`Source of Supply`,`CF.Vendor type`, `Company Name`, `Display Name`,`First Name`, `Last Name`, `EmailID`, `MobilePhone`,`GST Treatment`, `GST Identification Number (GSTIN)`, `PAN Number`, `Payment Terms`,`Billing Address`,`CF.Vendor District`,`Billing City`, `Billing State`, `Billing Country`, `Billing Code`,`Billing Phone`,`Shipping Address`,`Shipping City`, `Shipping State`, `Shipping Country`, `Shipping Code`,`Shipping Phone`,`CF.Voter ID`,`CF.Rate`,`Status`,`CF.PAN No`, `CF.Service Tax No`, `CF.TAN No`,`CF.ADHAAR No`,`CF.Name of Vendors Bank`, `CF.Banks Address`, `CF.Bank Account number`,`CF.Bank a/c holders name`,`CF.IFSC Code`, `CF.bank_file_path`, `CF.id_proof_file_path`,`CF.Payment Mode`,`CF.bill_number`,`CF.bill_file_path`) 
        VALUES ('$current_date','$place_of_supply','$vendor_type','$company_name','$company_name','$first_name','$last_name','$email','$contact','$gst_treatment','$gst_num','$pan_number','$payment_term','$billing_address','$district','$billing_city','$billing_state','$billing_country','$billing_zipcode','$billing_phone','$shipping_address','$shipping_city','$shipping_state','$shipping_country','$shipping_zipcode','$shipping_phone','$voter_id','$rate','Active','$pan_number','$gst_num','$tax_number','$adhaar_number','$bank_name', '$bank_address', '$account_number','$bank_holder_name', '$ifsc','$bank_path', '$id_proof_path','$payment_mode','$bill_number','$bill_file_path')";

        if ($con->query($insert_query) === TRUE) {
            $last_insert_id = $con->insert_id;
            $contact_name =  $company_name." - ".sprintf("%04d", $last_insert_id);
            $contact_id = "V".$last_insert_id;
            
            $res = $con->query("UPDATE `master_zoho_vendor` set `Contact Name` = '$contact_name', `CF.Contact ID` = '$contact_id' WHERE `id` = '$last_insert_id'");


            $res_temp = $con->query("UPDATE `temp_vendor` set `temp_status` = '1' WHERE `id` = '$id'");

       }
   }


if($last_insert_id == -1){
    $response['error'] = true;
    $response['message'] = "Already vendor exist";

}else if($last_insert_id >0){
    $response['error'] = false;

    $response['message'] = "Successfully vendor created";
    sendNotification($con,$created_by_id,$company_name);

}else{
    $response['error'] = true;
    $response['message'] = "Data not saved"/*.$con->error*/;
}


echo json_encode($response);

function getAppliedDate(){
    $now = new DateTime();
    return $now->format('Y-m-d H:i:s');
}


function getMiliSecond (){
   return round(microtime(true) * 1000);
}

function getFileExtension($file)
{

    $path_parts = pathinfo($file);
        //get extension
    return $path_parts['extension'];
}


function getFileName($file)
{

    $path_parts = pathinfo($file);
    return $path_parts['filename'];
}


function getUserName($con,$user_id){
    $userArray = "";
    $result = $con->query("SELECT * from `user` WHERE `id` = '$user_id'");
    if ($result->num_rows >0) {
        if ($row = $result->fetch_assoc()) {
            $userArray = $row['name'];
        }
    }
    return $userArray;
}


function sendNotification($con,$created_by_id,$display_contact_name){
    $userName = getUserName($con,$created_by_id);

    $ss= $con->query("SELECT `token` FROM `user_fcm_token` where `user_id` = '$created_by_id'");  

    $ch = curl_init("https://fcm.googleapis.com/fcm/send");

    $serverKey = "AIzaSyDJ0MiSBWBsQN5y-ybhWr2GNGFzTPsSfFQ";

    $notificationArr = array();
    array_push($notificationArr,array("user_name"=>$userName,"vendor"=>$display_contact_name));

    $notification = array("body" => array("module"=>"Approved Vendor","json_response"=>$notificationArr));

    while($r= ($ss->fetch_array())) {
        
        $f = $r['token'];
        $arrayToSend = array('to' => $f, 'data' => $notification);

        $json = json_encode($arrayToSend);
      // echo $json;
        $headers = array();
        $headers[] = "Content-Type: application/json";
        $headers[] = "Authorization: key= $serverKey";
        
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
        curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($ch);
        if($result === false)
        {
            //echo  'Curl failed ' . curl_error($ch);
        }

    }
    curl_close($ch);
}


?>