
<?php
date_default_timezone_set('Asia/Kolkata');
include "config/config.php";


$user_id = $_POST['user_id'];
$vendor_id = $_POST['vendor_id'];
$action = $_POST['action'];
$response = array();

//SELECT `id`, `payment_type`, `vendor_id`, `start_stay_date`, `end_stay_date`, `nights`, `user_id`, `rate`, `total_amount`, `created_by_id`, `created_date`, `modified_by_id`, `modified_date` FROM `emp_pay_vendor` WHERE 1

// SELECT `id`, `Created Time`, `Last Modified Time`, `Contact ID`, `Source of Supply`, `Contact Name`, `Display Name`, `Company Name`, `Salutation`, `First Name`, `Last Name`, `EmailID`, `Phone`, `MobilePhone`, `Skype Identity`, `Facebook`, `Twitter`, `Currency Code`, `Notes`, `Website`, `GST Treatment`, `GST Identification Number (GSTIN)`, `PAN Number`, `Payment Terms`, `Contact Address ID`, `Billing Attention`, `Billing Address`, `Billing Street2`, `Billing City`, `Billing State`, `Billing Country`, `Billing Code`, `Billing Phone`, `Billing Fax`, `Shipping Attention`, `Shipping Address`, `Shipping Street2`, `Shipping City`, `Shipping State`, `Shipping Country`, `Shipping Code`, `Shipping Phone`, `Shipping Fax`, `Source`, `Last Sync Time`, `Status`, `Vendor Payment`, `CF.Vendor type`, `CF.Payment Mode`, `CF.Contact ID`, `CF.Vendor District`, `CF.PAN No`, `CF.Service Tax No`, `CF.TAN No`, `CF.ADHAAR No`, `CF.Name of Vendors Bank`, `CF.Banks Address`, `CF.IFSC Code`, `CF.Bank a/c holders name`, `CF.Bank Account number`, `CF.bank_file_path`, `CF.id_proof_file_path`, `CF.bill_file_path`, `CF.bill_number`, `CF.Voter ID`, `CF.Rate` FROM `master_zoho_vendor` WHERE 1

$sql_query = "";
if (strtolower($action) == "submit") {
	$sql_query = "SELECT epv.*,mzv.`Contact Name`, mzv.`CF.Name of Vendors Bank` as bank_name, mzv.`CF.Banks Address` as bank_address, mzv.`CF.IFSC Code` as ifsc, mzv.`CF.Bank Account number` as account_number ,u.`name` from `emp_pay_vendor` as epv JOIN `master_zoho_vendor` as mzv on epv.`vendor_id` = mzv.`id` JOIN `user` as u on epv.`user_id` = u.`id` WHERE epv.`user_id` = '$user_id' AND epv.`vendor_id` = '$vendor_id' ORDER By epv.`status` DESC";
}else if (strtolower($action) == "approve" || strtolower($action) == "update"){
	$sql_query = "SELECT epv.*,mzv.`Contact Name`, mzv.`CF.Name of Vendors Bank` as bank_name, mzv.`CF.Banks Address` as bank_address, mzv.`CF.IFSC Code` as ifsc, mzv.`CF.Bank Account number` as account_number, u.`name` from `emp_pay_vendor` as epv JOIN `master_zoho_vendor` as mzv on epv.`vendor_id` = mzv.`id` JOIN `user` as u on epv.`user_id` = u.`id` ORDER By epv.`status` DESC";
}

$result = $con->query($sql_query);
if ($result->num_rows >0) {
	while ($row = $result->fetch_assoc()) {
		$status = "pending";
		if($row['status'] == "1"){
			$status = "approve";
		}
		array_push($response,array("id"=>$row['id'],"user_name"=>$row['name'],"vendor_id"=>$row['vendor_id'],"vendor_name"=>$row['Contact Name'],"bank_name"=>$row['bank_name'],"bank_address"=>$row['bank_address'],"ifsc"=>$row['ifsc'],"account_number"=>$row['account_number'],"start_stay_date"=>$row['start_stay_date'],"end_stay_date"=>$row['end_stay_date'],"nights"=>$row['nights'],"rate"=>$row['rate'],"total_amount"=>$row['total_amount'],"status"=>$status,"created_by_id"=>$row['created_by_id'],"created_date"=>$row['created_date']));
	}
}


echo json_encode($response);


function getUserData($con,$user_id){
	$user_name = "";
	$result = $con->query("SELECT * from `user` WHERE `id` = '$user_id'");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_assoc()) {
			$user_name = $row['name'];
		}
	}
	return $user_name;
}

function getVendorData($con,$vendor_id){
	$vendor_data = array();
	$result = $con->query("SELECT * from `master_zoho_vendor` WHERE `id` = '$vendor_id'");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_assoc()) {
			$vendor_data = $row;
		}
	}
	return $vendor_data;
}


?>