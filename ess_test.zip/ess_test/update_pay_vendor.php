<?php
date_default_timezone_set('Asia/Kolkata');
include "config/config.php";

$vendor_id = $_POST['vendor_id'];
$pay_vendor_id = $_POST['pay_vendor_id'];
$user_id = $_POST['user_id'];
$start_stay_date = $_POST['start_stay_date'];
$end_stay_date = $_POST['end_stay_date'];
$nights = $_POST['nights'];
$rate = $_POST['rate'];
$total_amount = $_POST['total_amount'];
$created_by_id = $_POST['created_by_id'];
$response = array();

$now = new DateTime();
$current_date =  $now->format('Y-m-d H:i:s');
$payment_type = "Vendor Advance Payment";

//SELECT `id`, `payment_type`, `vendor_id`, `start_stay_date`, `end_stay_date`, `nights`, `user_id`, `rate`, `total_amount`, `created_by_id`, `created_date`, `modified_by_id`, `modified_date` FROM `emp_pay_vendor` WHERE 1

$last_insert_id = 0;
$result = $con->query("UPDATE `emp_pay_vendor` set `start_stay_date`= '$start_stay_date',`end_stay_date` = '$end_stay_date',`nights` = '$nights',`total_amount` = '$total_amount',`rate`= '$rate',`status` = '1',`modified_by_id` = '$user_id',`modified_date`= '$current_date' WHERE `id` = '$pay_vendor_id'");

if ($con->affected_rows >0) {
	$last_insert_id = 1;
}


if ($last_insert_id == 0) {
	$response['error'] = true;
	$response['message'] = "Pay vendor not updated";
}else if ($last_insert_id > 0 ){
	$response['error'] = false;
	$response['message'] = "Successfully saved.";
	sendNotification($con,$created_by_id,$user_id,$vendor_id);

}

echo json_encode($response);


function getUserData($con,$user_id){
	$user_name = "";
	$result = $con->query("SELECT * from `user` WHERE `id` = '$user_id'");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_assoc()) {
			$user_name = $row['name'];
		}
	}
	return $user_name;
}

function getVendorName($con,$vendor_id){
	$vendor_name = "";
	$result = $con->query("SELECT * from `master_zoho_vendor` WHERE `id` = '$vendor_id'");
	if ($result->num_rows >0) {
		if ($row = $result->fetch_assoc()) {
			$vendor_name = $row['Display Name'];
		}
	}
	return $vendor_name;
}


function sendNotification($con,$created_by_id,$user_id,$vendor_id){
	$user_name = getUserData($con,$user_id);
	$vendor_name = getVendorName($con,$vendor_id);
	$token_query = "SELECT `token` from `user_fcm_token` WHERE `user_id` = '$created_by_id'";
	$ss= $con->query($token_query);

	$ch = curl_init("https://fcm.googleapis.com/fcm/send");
    $serverKey = "AIzaSyDJ0MiSBWBsQN5y-ybhWr2GNGFzTPsSfFQ";

	$notificationArr = array();
	array_push($notificationArr,array("vendor_name"=>$vendor_name,"user_name"=>$user_name));

	$notification = array("body" => array("module"=>"Response Pay vendor","json_response"=>$notificationArr));

	while($r= ($ss->fetch_array())) {

		$f = $r['token'];
		$arrayToSend = array('to' => $f, 'data' => $notification);

		$json = json_encode($arrayToSend);
      // echo $json;
		$headers = array();
		$headers[] = "Content-Type: application/json";
		$headers[] = "Authorization: key= $serverKey";

		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
		curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$result = curl_exec($ch);
		if($result === false)
		{
            //echo  'Curl failed ' . curl_error($ch);
		}

	}
	curl_close($ch);
}



?>