<?php
date_default_timezone_set('Asia/Kolkata');
include "config/config.php";

$customer_id = $_POST['customer_id'];
$user_id = $_POST['user_id'];
$role_id = $_POST['role_id'];
$country = $_POST['country'];
$state = $_POST['state'];

$userProjectArray = getUserProject($con,$user_id);
$related_table = getRelatedTable($con,$user_id);
$userProjectTypeIdArray = getUserProjectTypeId($con,$role_id,$related_table);


$response = array();

$result = $con->query("SELECT * from `master_zoho_project`");
if ($result->num_rows >0) {
	while ($row = $result->fetch_assoc()) {
		if (!in_array($row['id'],$userProjectArray)) {
			if (in_array($row['project_type_id'],$userProjectTypeIdArray)) {
				$project_type = getProjectType($con,$row['project_type_id']);
				$customer_name = getCustomerName($con,$row['cust_id']);
				array_push($response,array("id"=>$row['id'],"project_name"=>$row['Project Name'],"project_type_id"=>$row['project_type_id'],"project_type"=> $project_type,"project_type"=>$project_type,"Description"=>$row['Description'],"billing_ype"=>$row['Billing Type'],"project_cost"=>$row['Project Cost'],"customer_name"=>$customer_name,"cust_id"=>$row['cust_id'],"client_name"=>$row['client_name'],"currency_code"=>$row['Currency Code'],"budget_type"=>$row['Budget Type'],"budget_amount"=>$row['Budget Amount'],"project_budget_hours"=>$row['Project Budget Hours'],"estimated_days"=>$row['CF.Estimated Days'],"tl_ts_approver_id"=>$row['tl_ts_approver_id'],"location"=>$row['location'],"address"=>$row['address'],"district"=>$row['district'],"is_job_allocation_sheet"=>$row['is_job_allocation_sheet'],"is_system_backup"=>$row['is_system_backup'],"planned_start_date"=>$row['planned_start_date'],"planned_end_date"=>$row['planned_end_date'],"created_by"=>$row['created_by'],"name"=>$userName,"modified_by"=>$row['modified_by']));	
			}
		}
	}
}

echo json_encode($response);

function getUserProject($con,$user_id){
	$response  = array();
	$result = $con->query("SELECT DISTINCT(`project_id`) from `activity_user` WHERE `user_id` = '$user_id'");
	if ($result->num_rows >0) {
		while ($row = $result->fetch_assoc()) {
			array_push($response,$row['project_id']);
		}
	}
	return $response;
}

function getProjectType($con,$project_type_id){
    $project_type = "";
    $result = $con->query("SELECT `type` from `project_type` WHERE `id` = '$project_type_id' ");
    if ($result->num_rows >0) {
        if ($row = $result->fetch_assoc()) {
            $project_type = $row['type'];
        }
    }
    return $project_type;
}


function getCustomerName($con,$customerId){
    $customerName = "";
    $result = $con->query("SELECT * from `master_zoho_customer` where  `id` = '$customerId'");

    if ($result->nom_rows >=0){
        if ($row = $result->fetch_array()){
            $customerName = $row['Display Name'];
        }
    }
    return $customerName;
}

function getRelatedTable($con,$user_id){
	$related_table = "";
	$result = $con->query("SELECT * from `user` WHERE `id` = '$user_id'");
	if ($result->num_rows >0) {
		$row = $result->fetch_assoc();
		$related_table = $row['related_table'];
	}
	return $related_table;
}

function getUserProjectTypeId($con,$role_id,$related_table){
	$projectTypeArray = array();
	$result = $con->query("SELECT pt.`id` from $related_table as me join `project_type` as pt  on me.`org_unit_id` = pt.`org_unit_id` WHERE me.`id` = '$role_id'");

	if ($result->num_rows >0) {
		while($row = $result->fetch_assoc()){
			array_push($projectTypeArray,$row['id']);
		}
	}
	return $projectTypeArray;
}


?>