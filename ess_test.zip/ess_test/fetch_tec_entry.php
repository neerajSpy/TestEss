<?php
include "config/config.php";

date_default_timezone_set('Asia/Kolkata');

$tec_id = $_POST['tec_id'];


//SELECT `id`, `tec_id`, `entry_category`, `travel_mode`, `deprt_date`, `deprt_time`, `arrival_date`, `arrival_time`, `location`, `from_location`, `to_location`, `kilo_meter`, `mileage`, `unit_price`, `vendor`, `total_quantitty`, `description`, `date`, `paid_to`, `paid_by`, `gstin`, `bill_amount`, `bill_num`, `attachment_path` FROM `emp_tec_entry` WHERE 1

$entryCategoryArray = array('Intercity Travel cost','Food - Boarding - Per Diem','Local Travel - Public transport','Miscellaneous','Repairs and Maintenance','Intl Travel Insurance','Fuel/Mileage Expenses - Own transport','Lodging - Hotels','Fixed Asset','Minutes of Meeting','Service Timesheet','Feedback Form','SAT Report','Checklists');

$response = array();
$intercityTravelCostResponse = array();
$FoodBoardingResponse = array();
$LocalTravelResponse = array();
$MiscellaneousResponse = array();
$RepairsResponse = array();
$IntlTravelInsuranceResponse = array();
$FuelMileageResponse = array();
$LodgingHotelsResponse = array();
$FixedAssetResponse = array();
$MOMResponse = array();
$ServiceTimesheetResponse = array();
$FeedbackResponse = array();
$SATResponse = array();
$ChecklistResponse = array();

$sub_result = $con->query("SELECT * FROM `emp_tec_entry` WHERE `tec_id` = '$tec_id' AND `is_active` = '0' ORDER By `entry_category`, CONCAT(`deprt_date`,' ',`deprt_time`) ASC");
if ($sub_result->num_rows >0) {

	$intercityTravelCost = 0;
	$FoodBoarding = 0;
	$LocalTravel = 0;
	$Miscellaneous = 0;
	$Repairs = 0;
	$IntlTravelInsurance = 0;
	$FuelMileage = 0;
	$LodgingHotels = 0;
	$FixedAsset = 0;

// employee Paid
	$intercityTravelCostEmp = 0;
	$FoodBoardingEmp = 0;
	$LocalTravelEmp = 0;
	$MiscellaneousEmp = 0;
	$RepairsEmp = 0;
	$IntlTravelInsuranceEmp = 0;
	$FuelMileageEmp = 0;
	$LodgingHotelsEmp = 0;
	$FixedAssetEmp = 0;

// Account Paid
	$intercityTravelCostAC = 0;
	$FoodBoardingAC = 0;
	$LocalTravelAC = 0;
	$MiscellaneousAC = 0;
	$RepairsAC = 0;
	$IntlTravelInsuranceAC = 0;
	$FuelMileageAC = 0;
	$LodgingHotelsAC = 0;
	$FixedAssetAC = 0;

	while ($subRow = $sub_result->fetch_assoc()) {

		if(strtolower($subRow['entry_category']) == strtolower("Intercity Travel cost")){
			array_push($intercityTravelCostResponse,$subRow);
			$intercityTravelCost = $intercityTravelCost + $subRow['bill_amount'];
			
			if (strtolower($subRow['paid_by']) == "employee") 
				$intercityTravelCostEmp = $intercityTravelCostEmp + $subRow['bill_amount'];
			else
				$intercityTravelCostAC = $intercityTravelCostAC + $subRow['bill_amount'];


		}else if(strtolower($subRow['entry_category']) == strtolower("Food - Boarding - Per Diem")){
			array_push($FoodBoardingResponse,$subRow);
			$FoodBoarding = $FoodBoarding + $subRow['bill_amount'];
			if (strtolower($subRow['paid_by']) == "employee") 
				$FoodBoardingEmp = $FoodBoardingEmp + $subRow['bill_amount'];
			else
				$FoodBoardingAC = $FoodBoardingAC + $subRow['bill_amount'];
		}else if(strtolower($subRow['entry_category']) == strtolower("Local Travel - Public transport")){
			array_push($LocalTravelResponse,$subRow);
			$LocalTravel = $LocalTravel + $subRow['bill_amount'];
			
			if (strtolower($subRow['paid_by']) == "employee") 
				$LocalTravelEmp = $LocalTravelEmp + $subRow['bill_amount'];
			else
				$LocalTravelAC = $LocalTravelAC + $subRow['bill_amount'];
		}else if(strtolower($subRow['entry_category']) == strtolower("Miscellaneous")){
			array_push($MiscellaneousResponse,$subRow);
			$Miscellaneous = $Miscellaneous + $subRow['bill_amount'];
			if (strtolower($subRow['paid_by']) == "employee") 
				$MiscellaneousEmp = $MiscellaneousEmp + $subRow['bill_amount'];
			else
				$MiscellaneousAC = $MiscellaneousAC + $subRow['bill_amount'];
		}else if(strtolower($subRow['entry_category']) == strtolower("Repairs and Maintenance")){
			array_push($RepairsResponse,$subRow);
			$Repairs = $Repairs + $subRow['bill_amount'];
			if (strtolower($subRow['paid_by']) == "employee") 
				$RepairsEmp = $RepairsEmp + $subRow['bill_amount'];
			else
				$RepairsAC = $RepairsAC + $subRow['bill_amount'];
		}else if(strtolower($subRow['entry_category']) == strtolower("Intl Travel Insurance")){
			array_push($IntlTravelInsuranceResponse,$subRow);
			$IntlTravelInsurance = $IntlTravelInsurance + $subRow['bill_amount'];
			if (strtolower($subRow['paid_by']) == "employee") 
				$IntlTravelInsuranceEmp = $IntlTravelInsuranceEmp + $subRow['bill_amount'];
			else
				$IntlTravelInsuranceAC = $IntlTravelInsuranceAC + $subRow['bill_amount'];
		}else if(strtolower($subRow['entry_category']) == strtolower("Fuel/Mileage Expenses - Own transport")){
			array_push($FuelMileageResponse,$subRow);
			$FuelMileage = $FuelMileage + $subRow['bill_amount'];
			if (strtolower($subRow['paid_by']) == "employee") 
				$FuelMileageEmp = $FuelMileageEmp + $subRow['bill_amount'];
			else
				$FuelMileageAC = $FuelMileageAC + $subRow['bill_amount'];
		}else if(strtolower($subRow['entry_category']) == strtolower("Lodging - Hotels")){
			array_push($LodgingHotelsResponse,$subRow);
			$LodgingHotels = $LodgingHotels + $subRow['bill_amount'];
			if (strtolower($subRow['paid_by']) == "employee") 
				$LodgingHotelsEmp = $LodgingHotelsEmp + $subRow['bill_amount'];
			else
				$LodgingHotelsAC = $LodgingHotelsAC + $subRow['bill_amount'];
		}else if(strtolower($subRow['entry_category']) == strtolower("Fixed Asset")){
			array_push($FixedAssetResponse,$subRow);
			$FixedAsset = $FixedAsset + $subRow['bill_amount'];
			if (strtolower($subRow['paid_by']) == "employee") 
				$FixedAssetEmp = $FixedAssetEmp + $subRow['bill_amount'];
			else
				$FixedAssetAC = $FixedAssetAC + $subRow['bill_amount'];
		}else if(strtolower($subRow['entry_category']) == strtolower("Minutes of Meeting")){
			array_push($MOMResponse,$subRow);
		}else if(strtolower($subRow['entry_category']) == strtolower("Service Timesheet")){
			array_push($ServiceTimesheetResponse,$subRow);
		}else if(strtolower($subRow['entry_category']) == strtolower("Feedback Form")){
			array_push($FeedbackResponse,$subRow);
		}else if(strtolower($subRow['entry_category']) == strtolower("SAT Report")){
			array_push($SATResponse,$subRow);
		}else if(strtolower($subRow['entry_category']) == strtolower("Checklists")){
			array_push($ChecklistResponse,$subRow);
		}

	}
}


if (sizeof($intercityTravelCostResponse) >0) {
	array_push($response,array("category"=>$entryCategoryArray[0],"total_amount"=>$intercityTravelCost,"emp_amount"=>$intercityTravelCostEmp,"ac_amount"=>$intercityTravelCostAC,"response"=>$intercityTravelCostResponse));

}if (sizeof($FoodBoardingResponse) >0) {
	array_push($response,array("category"=>$entryCategoryArray[1],"total_amount"=>$FoodBoarding,"emp_amount"=>$FoodBoardingEmp,"ac_amount"=>$FoodBoardingAC,"response"=>$FoodBoardingResponse));
	
}if (sizeof($LocalTravelResponse) >0) {
	array_push($response,array("category"=>$entryCategoryArray[2],"total_amount"=>$LocalTravel,"emp_amount"=>$LocalTravelEmp,"ac_amount"=>$LocalTravelAC,"response"=>$LocalTravelResponse));
	
}if (sizeof($MiscellaneousResponse) >0) {
	array_push($response,array("category"=>$entryCategoryArray[3],"total_amount"=>$Miscellaneous,"emp_amount"=>$MiscellaneousEmp,"ac_amount"=>$MiscellaneousAC,"response"=>$MiscellaneousResponse));
	
}if (sizeof($RepairsResponse) >0) {
	array_push($response,array("category"=>$entryCategoryArray[4],"total_amount"=>$Repairs,"emp_amount"=>$RepairsEmp,"ac_amount"=>$RepairsAC,"response"=>$RepairsResponse));
	
}if (sizeof($IntlTravelInsuranceResponse) >0) {
	array_push($response,array("category"=>$entryCategoryArray[5],"total_amount"=>$IntlTravelInsurance,"emp_amount"=>$IntlTravelInsuranceEmp,"ac_amount"=>$IntlTravelInsuranceAC,"response"=>$IntlTravelInsuranceResponse));
	
}if (sizeof($FuelMileageResponse) >0) {
	array_push($response,array("category"=>$entryCategoryArray[6],"total_amount"=>$FuelMileage,"emp_amount"=>$FuelMileageEmp,"ac_amount"=>$FuelMileageAC,"response"=>$FuelMileageResponse));
	
}if (sizeof($LodgingHotelsResponse) >0) {
	array_push($response,array("category"=>$entryCategoryArray[7],"total_amount"=>$LodgingHotels,"emp_amount"=>$LodgingHotelsEmp,"ac_amount"=>$LodgingHotelsAC,"response"=>$LodgingHotelsResponse));
	
}if (sizeof($FixedAssetResponse) >0) {
	array_push($response,array("category"=>$entryCategoryArray[8],"total_amount"=>$FixedAsset,"emp_amount"=>$FixedAssetEmp,"ac_amount"=>$FixedAssetAC,"response"=>$FixedAssetResponse));
}
if(sizeof($MOMResponse) >0){
	array_push($response,array("category"=>$entryCategoryArray[9],"total_amount"=>0,"emp_amount"=>0,"ac_amount"=>0,"response"=>$MOMResponse));
} 
if(sizeof($ServiceTimesheetResponse) >0){
	array_push($response,array("category"=>$entryCategoryArray[10],"total_amount"=>0,"emp_amount"=>0,"ac_amount"=>0,"response"=>$ServiceTimesheetResponse));
} if(sizeof($FeedbackResponse) >0){
	array_push($response,array("category"=>$entryCategoryArray[11],"total_amount"=>0,"emp_amount"=>0,"ac_amount"=>0,"response"=>$FeedbackResponse));
} if(sizeof($SATResponse) >0){
	array_push($response,array("category"=>$entryCategoryArray[12],"total_amount"=>0,"emp_amount"=>0,"ac_amount"=>0,"response"=>$SATResponse));
}if(sizeof($ChecklistResponse) >0){
	array_push($response,array("category"=>$entryCategoryArray[13],"total_amount"=>0,"emp_amount"=>0,"ac_amount"=>0,"response"=>$ChecklistResponse));
}



echo json_encode($response);

function getUserName($con,$role_id){
	$userName = "";
	$result = $con->query("SELECT * from `user` where `role_id` = '$role_id'");
	if ($result->num_rows >0) {
		if($row = $result->fetch_array()){
			$userName = $row['name'];

		}
	}
	return $userName;
}

function getProjectName($con,$project_id){
	$project_name = "";
	$result = $con->query("SELECT * from `master_zoho_project` where `id` = '$project_id'");
	if ($result->num_rows >0) {
		if($row = $result->fetch_array()){
			$project_name = $row['Project Name'];

		}
	}
	return $project_name;	
}
?>