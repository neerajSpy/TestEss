<?php
include "config/config.php";

date_default_timezone_set('Asia/Kolkata');

$role_id = $_POST['role_id'];
$control_id = $_POST['control_id'];
$project_id = $_POST['project_id'];


$query ="";

if ($project_id !='') {
	$query = "SELECT * from `emp_main_tec` where `role_id` = '$role_id' AND `project_id` = '$project_id' ORDER BY `id` DESC";
}
else {
$query = "SELECT * from `emp_main_tec` ORDER BY `id` DESC";	
}


$response = array();

$result = $con->query($query);
if ($result->num_rows >0) {
	while ($main_row = $result->fetch_assoc()) {
		$tec_id = $main_row['id'];
		$role_id = $main_row['role_id'];
		$userName = getUserName($con,$role_id);
		$project_id = $main_row['project_id'];
		$projectName = getProjectName($con,$project_id);
//SELECT `id`, `tec_id`, `entry_category`, `location`, `unit_price`, `total_quantitty`, `description`, `date`, `paid_to`, `paid_by`, `gstin`, `bill_amount`, `bill_num`, `attachment_path` FROM `emp_tec_entry` WHERE 1

		$subArray = array();
		$total_bill = 0;
		$sub_result = $con->query("SELECT * FROM `emp_tec_entry` WHERE `tec_id` = '$tec_id'");
		if ($sub_result->num_rows >0) {
			while ($subRow = $sub_result->fetch_assoc()) {

				$total_bill = $total_bill + $subRow['bill_amount'];

				array_push($subArray,array("id"=>$subRow['id'],"entry_category"=>$subRow['entry_category'],"travel_mode"=>$subRow['travel_mode'],"location"=>$subRow['location'],"departure_date"=>$subRow['deprt_date'],"departure_time"=>$subRow['deprt_time'],"arrival_date"=>$subRow['arrival_date'],"arrival_time"=>$subRow['arrival_time'],"vendor"=>$subRow['vendor'],"unit_price"=>$subRow['unit_price'],"total_quantitty"=>$subRow['total_quantitty'],"description"=>$subRow['description'],"date"=>$subRow['date'],"paid_to"=>$subRow['paid_to'],"paid_by"=>$subRow['paid_by'],"gstin"=>$subRow['gstin'],"bill_amount"=>$subRow['bill_amount'],"bill_num"=>$subRow['bill_num'],"attachment_path"=>$subRow['attachment_path']));


			}
		}

		array_push($response,array("tec_id"=>$tec_id,"user_name"=>$userName,"project_id"=>$project_id,"project_name"=>$projectName,"request_date"=>$main_row['request_date'],"status"=>$main_row['status'],"total_bill"=>$total_bill,"description"=>$main_row['description'],"created_by_id"=>$main_row['created_by_id'],"entry_response"=>$subArray));
	}
}


echo json_encode($response);

function getUserName($con,$role_id){
	$userName = "";
	$result = $con->query("SELECT * from `user` where `role_id` = '$role_id'");
	if ($result->num_rows >0) {
		if($row = $result->fetch_array()){
			$userName = $row['name'];

		}
	}
	return $userName;
}

function getProjectName($con,$project_id){
$project_name = "";
	$result = $con->query("SELECT * from `master_zoho_project` where `id` = '$project_id'");
	if ($result->num_rows >0) {
		if($row = $result->fetch_array()){
			$project_name = $row['Project Name'];

		}
	}
	return $project_name;	
}
?>