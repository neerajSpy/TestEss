    <?php

    include "config/config.php";
    date_default_timezone_set('Asia/Kolkata');

    //{"account_number":"fghhhfd","adhaar_number":"ddsff","bank_address":"vvhhhnb","bank_name":"741588","billing_address":"thanks so much for",
    //"billing_city":"thanks","billing_country":"djsk","billing_phone":"7664666343","billing_state":"thanks","billing_zipcode":"12282",
    //"contact":"7664666343","display_contact_name":"we the","email":"nk88337@gmail.com","first_name":"thanks","gst_num":"4677",
    //"gst_treatment":"Registered Business - Composition","id":0,"ifsc":"147788","last_name":"thanks",
    //"pan_number":"fddf","payment_term":"Net 15","place_of_supply":"Registered Business - Regular",
    //"service_tax_number":"ddgh","shipping_address":"thanks so much for","shipping_city":"thanks","shipping_country":"djsk",
    //"shipping_phone":"7664666343","shipping_state":"thanks","shipping_zipcode":"12282","tax_number":"fdv"}

    $vendor_json = json_decode($_POST['vendor_json']);
    $user_id = $_POST['user_id'];

    $id_proof_attachment = "";
    if(isset($_FILES['id_proof_attachment']['tmp_name']))
        $id_proof_attachment = $_FILES['id_proof_attachment']['tmp_name'];

    $bank_name_attachment = "";
    if(isset($_FILES['bank_name_attachment']['tmp_name']))
        $bank_name_attachment = $_FILES['bank_name_attachment']['tmp_name'];
    
    $bill_file_attachment = "";
    if(isset($_FILES['bill_attachment']['tmp_name'])){
        $bill_file_attachment = $_FILES['bill_attachment']['tmp_name'];
    }

    $first_name = $vendor_json->first_name;
    $last_name = $vendor_json->last_name;
    $company_name = $vendor_json->company_name;
    $email = $vendor_json->email;
    $contact = $vendor_json->contact;
    $gst_treatment = $vendor_json->gst_treatment;
    $gst_num = $vendor_json->gst_num;
    $place_of_supply = $vendor_json->place_of_supply;
    $payment_term = $vendor_json->payment_term;
    $billing_address = $vendor_json->billing_address;
    $district = $vendor_json->district;
    $billing_city = $vendor_json->billing_city;
    $billing_state = $vendor_json->billing_state;
    $billing_country = $vendor_json->billing_country;
    $billing_zipcode = $vendor_json->billing_zipcode;
    $billing_address = $vendor_json->billing_address;
    $billing_phone = $vendor_json->billing_phone;
    $shipping_city = $vendor_json->shipping_city;
    $shipping_state = $vendor_json->shipping_state;
    $shipping_zipcode = $vendor_json->shipping_zipcode;
    $shipping_country = $vendor_json->shipping_country;
    $shipping_address = $vendor_json->shipping_address;
    $shipping_phone = $vendor_json->shipping_phone;
    $pan_number = $vendor_json->pan_number;
    $service_tax_number = $vendor_json->service_tax_number;
    $tax_number = $vendor_json->tax_number;
    $adhaar_number = $vendor_json->adhaar_number;
    $bank_name = $vendor_json->bank_name;
    $bank_address = $vendor_json->bank_address;
    $ifsc = $vendor_json->ifsc;
    $vendor_type = $vendor_json->vendor_type;
    $account_number = $vendor_json->account_number;
    $bank_holder_name = $vendor_json->bank_holder_name;
    $createdById = $vendor_json->created_by_id;
    $rate = $vendor_json->rate;
    $voter_id = $vendor_json->voter_id;
    $payment_mode = $vendor_json->payment_mode;
    $bill_number = $vendor_json->bill_number;
    $gst_treatment = $vendor_json->gst_treatment;

    $current_date = getAppliedDate();
    $basePath = "http://ess.technitab.in/web_service/ESS/";

    $response = array();

    if($vendor_type == ""){
        $vendor_type = "Hotel";
    }


    if (strtolower($gst_treatment) == 'registered business - regular') {
        $gst_treatment = "business_gst";
    }else if (strtolower($gst_treatment) == "Unregistered Business"){
        $gst_treatment = "business_none";
    }
    


    /*
    $id_proof_attachment = $_POST['id_proof_attachment'];
    $gst_num_attachment = $_POST['gst_num_attachment'];
    $adhaar_number_attachment = $_POST['adhaar_number_attachment'];
    $bank_name_attachment = $_POST['bank_name_attachment'];*/

    $id_proof_path = "";
    $idFileName = "";
    if($id_proof_attachment != ""){

        $idFileName =  $user_id.'_'.getMiliSecond()."_".rand().'.' .getFileExtension($_FILES['id_proof_attachment']['name']);
        $id_proof_path = $basePath.'vendor_doc_pic/'. $idFileName;

    }

    $bank_path = "";
    $bankFileName="";
    if($bank_name_attachment != ""){

        $bankFileName =  $user_id.'_'.getMiliSecond()."_".rand(). '.' .getFileExtension($_FILES['bank_name_attachment']['name']);
        $bank_path = $basePath.'vendor_doc_pic/'. $bankFileName;
    }

    $bill_file_path = "";
    $billFileName = "";
    if ($bill_file_attachment != "") {
        $billFileName =  $user_id.'_'.getMiliSecond()."_".rand(). '.' .getFileExtension($_FILES['bill_attachment']['name']);
        $bill_file_path = $basePath.'vendor_doc_pic/'. $billFileName;
    }

 $companyName = $company_name;
    if ($company_name == "") {
        $companyName = $first_name." ".$last_name;
    }

//SELECT `id`, `Created Time`, `Last Modified Time`, `Contact ID`, `Source of Supply`, `Contact Name`, `Display Name`, `Company Name`, `Salutation`, `First Name`, `Last Name`, `EmailID`, `Phone`, `MobilePhone`, `Skype Identity`, `Facebook`, `Twitter`, `Currency Code`, `Notes`, `Website`, `GST Treatment`, `GST Identification Number (GSTIN)`, `PAN Number`, `Payment Terms`, `Contact Address ID`, `Billing Attention`, `Billing Address`, `Billing Street2`, `Billing City`, `Billing State`, `Billing Country`, `Billing Code`, `Billing Phone`, `Billing Fax`, `Shipping Attention`, `Shipping Address`, `Shipping Street2`, `Shipping City`, `Shipping State`, `Shipping Country`, `Shipping Code`, `Shipping Phone`, `Shipping Fax`, `Source`, `Last Sync Time`, `Status`, `Vendor Payment`, `CF.Vendor type`, `CF.Payment Mode`, `CF.Contact ID`, `CF.Vendor District`, `CF.PAN No`, `CF.Service Tax No`, `CF.TAN No`, `CF.ADHAAR No`, `CF.Name of Vendor's Bank`, `CF.Bank's Address`, `CF.IFSC Code`, `CF.Bank a/c holder's name`, `CF.Bank Account number`, `CF.bill_file_path`, `CF.bill_number`, `CF.Voter ID`, `CF.Rate`, `CF.bank_file_path`, `CF.id_proof_file_path`, `created_by_id`, `created_date`, `modified_by_id`, `modified_date`, `temp_status` FROM `z_temp_temp_vendor` WHERE 1

    $last_insert_id = -1;


    $result = $con->query("SELECT * from `temp_vendor` where `Display Name` = '$companyName' AND `is_active` = '0'");
    if ($result->num_rows < 1){
        $last_insert_id = 0;

        $insert_query = "INSERT INTO `temp_vendor` (`Created Time`,`Source of Supply`,`CF.Vendor type`, `Company Name`, `Display Name`,`First Name`, `Last Name`, `EmailID`, `MobilePhone`,`GST Treatment`, `GST Identification Number (GSTIN)`, `PAN Number`, `Payment Terms`,`Billing Address`,`CF.Vendor District`,`Billing City`, `Billing State`, `Billing Country`, `Billing Code`,`Billing Phone`,`Shipping Address`,`Shipping City`, `Shipping State`, `Shipping Country`, `Shipping Code`,`Shipping Phone`,`CF.Voter ID`,`CF.Rate`,`Status`,`CF.PAN No`, `CF.Service Tax No`, `CF.TAN No`,`CF.ADHAAR No`,`CF.Name of Vendors Bank`, `CF.Banks Address`,`CF.Bank a/c holders name` ,`CF.Bank Account number`,`CF.IFSC Code`, `CF.bank_file_path`, `CF.id_proof_file_path`,`CF.Payment Mode`,`CF.bill_number`,`CF.bill_file_path`,`created_by_id`) 
        VALUES ('$current_date','$place_of_supply','$vendor_type','$company_name','$company_name','$first_name','$last_name','$email','$contact','$gst_treatment','$gst_num','$pan_number','$payment_term','$billing_address','$district','$billing_city','$billing_state','$billing_country','$billing_zipcode','$billing_phone','$shipping_address','$shipping_city','$shipping_state','$shipping_country','$shipping_zipcode','$shipping_phone','$voter_id','$rate','Active','$pan_number','$gst_num','$tax_number','$adhaar_number','$bank_name', '$bank_address','$bank_holder_name', '$account_number', '$ifsc','$bank_path', '$id_proof_path','$payment_mode','$bill_number','$bill_file_path','$user_id')";

        if ($con->query($insert_query) === TRUE) {
            $last_insert_id = $con->insert_id;

            $contact_name = ""; 
            if (strlen(trim($company_name)) < 1) {
                $company_name = $first_name . " ". $last_name;
            }
            $contact_name =  $company_name." - ".sprintf("%04d", $last_insert_id);
            $contact_id = "V".$last_insert_id;
            
            $res = $con->query("UPDATE `temp_vendor` set `Contact Name` = '$contact_name',`Display Name` = '$contact_name', `CF.Contact ID` = '$contact_id' WHERE `id` = '$last_insert_id'");


            if($id_proof_path != ""){
                $targetPath = $_SERVER['DOCUMENT_ROOT']."/web_service/ESS/vendor_doc_pic/".$idFileName; 
                if(move_uploaded_file($id_proof_attachment, $targetPath)) {
               //echo "tax_number attached";
                } 
            }

            if($bank_path != ""){
                $targetPath = $_SERVER['DOCUMENT_ROOT']."/web_service/ESS/vendor_doc_pic/".$bankFileName; 
                if(move_uploaded_file($bank_name_attachment, $targetPath)) {
              // echo "bank attached";
                } 
            }if($bill_file_path != ""){
                $targetPath = $_SERVER['DOCUMENT_ROOT']."/web_service/ESS/vendor_doc_pic/".$billFileName; 
                if(move_uploaded_file($bill_file_attachment, $targetPath)) {
              // echo "bank attached";
                } 
            }

        }
    }


    if($last_insert_id == -1){
        $response['error'] = true;
        $response['message'] = "Already vendor exist";

    }else if($last_insert_id >0){
        $response['error'] = false;
        $response['message'] = "Successfully vendor created";
        sendNotification($con,$user_id,$company_name);

    }else{
        $response['error'] = true;
        $response['message'] = "Data not saved"/*.$con->error*/;
    }


    echo json_encode($response);

    function getAppliedDate(){
        $now = new DateTime();
        return $now->format('Y-m-d H:i:s');
    }


    function getMiliSecond (){
     return round(microtime(true) * 1000);
 }

 function getFileExtension($file)
 {

    $path_parts = pathinfo($file);
        //get extension
    return $path_parts['extension'];
}


function getFileName($file)
{

    $path_parts = pathinfo($file);
    return $path_parts['filename'];
}


function getUserData($con,$user_id){
    $userArray = array();
    $result = $con->query("SELECT * from `user` WHERE `id` = '$user_id'");
    if ($result->num_rows >0) {
        if ($row = $result->fetch_assoc()) {
            $userArray['name'] = $row['name'];
            $userId = $row['id'];
        }
    }
    return $userArray;
}

function sendNotification($con,$user_id,$display_contact_name){
    $userData = getUserData($con,$user_id);
    
    $ss= $con->query("SELECT uft.`token`  from `user` as u JOIN `user_fcm_token` as uft on u.`id` = uft.`user_id` WHERE u.`access_control_id` = 2");  

    $ch = curl_init("https://fcm.googleapis.com/fcm/send");

    $serverKey = "AIzaSyDJ0MiSBWBsQN5y-ybhWr2GNGFzTPsSfFQ";

    $notificationArr = array();
    array_push($notificationArr,array("user_name"=>$userData['name'],"display_contact_name"=>$display_contact_name));

    $notification = array("body" => array("module"=>"Vendor Request","json_response"=>$notificationArr));

    while($r= ($ss->fetch_array())) {

        $f = $r['token'];
        $arrayToSend = array('to' => $f, 'data' => $notification);

        $json = json_encode($arrayToSend);
      // echo $json;
        $headers = array();
        $headers[] = "Content-Type: application/json";
        $headers[] = "Authorization: key= $serverKey";

        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
        curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($ch);
        if($result === false)
        {
            //echo  'Curl failed ' . curl_error($ch);
        }

    }
    curl_close($ch);


}

?>