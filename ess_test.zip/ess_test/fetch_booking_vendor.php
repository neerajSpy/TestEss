<?php
include "config/config.php";

$project_id = $_POST['project_id'];
$travel_type = $_POST['travel_type'];
$booking_mode = $_POST['booking_mode'];
$response = array();


$vendors = array();
if($booking_mode == "Hotel" && $travel_type != "Return Journey"){
	$vendors = getProjectDistrictVendors($con,$project_id);
}else if($booking_mode == "Travel"){
	$vendors = getTravelVendors($con,$booking_mode);
}


echo json_encode($vendors);

function getProjectDistrictVendors($con,$project_id){
	$districtArray = array();

	$result = $con->query("SELECT * from `master_zoho_vendor` WHERE `Billing State` = (SELECT `state` from `master_zoho_project` WHERE `id` = '$project_id') AND `CF.Vendor type` = 'Hotel'");

	if ($result->num_rows >0) {
		while ($row = $result->fetch_assoc()) {
			 $gst_treatment = $row['GST Treatment'];
            if ($gst_treatment == "business_gst") {
                $gst_treatment = "Registered Business - Regular";
            }else {
                $gst_treatment = "unregistered business";
            }

            array_push($districtArray,array("id"=>$row['id'],"vendor_type_id"=>"0","vendor_type"=>$row['CF.Vendor type'],"first_name"=>$row['First Name'],"last_name"=>$row['Last Name'],"contact_name"=>$row['Contact Name'],"display_name"=>$row['Display Name'],"company_name"=>$row['Company Name'],"email"=>$row['EmailID'],"contact"=>$row['MobilePhone'],"gst_treatment"=>$gst_treatment,"gst_num"=>$row['GST Identification Number (GSTIN)'],"district"=>$row['CF.Vendor District'],"place_of_supply"=>$row['Source of Supply'],"payment_term"=>$row['Payment Terms'],"billing_address"=>$row['Billing Address'],"billing_city"=>$row['Billing City'],"billing_state"=>$row['Billing State'],"billing_zipcode"=>$row['Billing Code'],"billing_country"=>$row['Billing Country'],"billing_phone"=>$row['Billing Phone'],"shipping_address"=>$row['Shipping Address'],"shipping_city"=>$row['Shipping City'],"shipping_state"=>$row['Shipping State'],"shipping_zipcode"=>$row['Shipping Code'],"shipping_country"=>$row['Shipping Country'],"shipping_phone"=>$row['Shipping Phone'],"pan_number"=>$row['CF.PAN No'],"service_tax_number"=>$row['CF.Service Tax No'],"tax_number"=>$row['CF.TAN No'],"adhaar_number"=>$row['CF.ADHAAR No'],"bank_name"=>$row['CF.Name of Vendors Bank'],"bank_holder_name"=>$row['CF.Bank a/c holders name'],"bank_address"=>$row['CF.Banks Address'],"ifsc"=>$row['CF.IFSC Code'],"account_number"=>$row['CF.Bank Account number'],"bank_file"=>$row['CF.bank_file_path'],"id_proof_file"=>$row['CF.id_proof_file_path'],"created_by_id"=>$row['created_by_id'],"voter_id"=>$row['CF.Voter ID'],"rate"=>$row['CF.Rate'],"payment_mode"=>$row['CF.Payment Mode'],"bill_file"=>$row['CF.bill_file_path'],"bill_number"=>$row['CF.bill_number']));
		}
	}
	return $districtArray;
}

function getTravelVendors($con,$booking_mode){
	$response = array();
	$result = $con->query("SELECT * from `master_zoho_vendor` WHERE `CF.Vendor type` = '$booking_mode'");
	if ($result->num_rows >0) {
		while ($row = $result->fetch_assoc()) {
			 $gst_treatment = $row['GST Treatment'];
            if ($gst_treatment == "business_gst") {
                $gst_treatment = "Registered Business - Regular";
            }else {
                $gst_treatment = "unregistered business";
            }

            array_push($response,array("id"=>$row['id'],"vendor_type_id"=>"0","vendor_type"=>$row['CF.Vendor type'],"first_name"=>$row['First Name'],"last_name"=>$row['Last Name'],"contact_name"=>$row['Contact Name'],"display_name"=>$row['Display Name'],"company_name"=>$row['Company Name'],"email"=>$row['EmailID'],"contact"=>$row['MobilePhone'],"gst_treatment"=>$gst_treatment,"gst_num"=>$row['GST Identification Number (GSTIN)'],"district"=>$row['CF.Vendor District'],"place_of_supply"=>$row['Source of Supply'],"payment_term"=>$row['Payment Terms'],"billing_address"=>$row['Billing Address'],"billing_city"=>$row['Billing City'],"billing_state"=>$row['Billing State'],"billing_zipcode"=>$row['Billing Code'],"billing_country"=>$row['Billing Country'],"billing_phone"=>$row['Billing Phone'],"shipping_address"=>$row['Shipping Address'],"shipping_city"=>$row['Shipping City'],"shipping_state"=>$row['Shipping State'],"shipping_zipcode"=>$row['Shipping Code'],"shipping_country"=>$row['Shipping Country'],"shipping_phone"=>$row['Shipping Phone'],"pan_number"=>$row['CF.PAN No'],"service_tax_number"=>$row['CF.Service Tax No'],"tax_number"=>$row['CF.TAN No'],"adhaar_number"=>$row['CF.ADHAAR No'],"bank_name"=>$row['CF.Name of Vendors Bank'],"bank_holder_name"=>$row['CF.Bank a/c holders name'],"bank_address"=>$row['CF.Banks Address'],"ifsc"=>$row['CF.IFSC Code'],"account_number"=>$row['CF.Bank Account number'],"bank_file"=>$row['CF.bank_file_path'],"id_proof_file"=>$row['CF.id_proof_file_path'],"created_by_id"=>$row['created_by_id'],"voter_id"=>$row['CF.Voter ID'],"rate"=>$row['CF.Rate'],"payment_mode"=>$row['CF.Payment Mode'],"bill_file"=>$row['CF.bill_file_path'],"bill_number"=>$row['CF.bill_number']));
		}
	}
	return $response;
}


?>