<?php
include "config/config.php";
date_default_timezone_set('Asia/Kolkata');

$project_type_id = $_POST['project_type_id'];


////SELECT `id`, `activity_type`, `project_type_id`, `is_default`, `created_by`, `modified_by`, `is_active`, `created`, `modified` FROM `project_type_activity_type` WHERE 1

$response = array();
$result = $con->query("SELECT * FROM `project_type_activity_type` WHERE `project_type_id` = '$project_type_id'");

if ($result->num_rows >0) {
	while ($row = $result->fetch_array()) {
		array_push($response, array("id"=>$row['id'],"activity_type"=>$row['activity_type']));
	}
}

echo json_encode($response);


?>
