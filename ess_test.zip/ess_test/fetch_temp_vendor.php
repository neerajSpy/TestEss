    <?php
    
    include "config/config.php";
    date_default_timezone_set('Asia/Kolkata');

    $user_id = $_POST['user_id'];
    $action = $_POST['action'];

    $sql_query = "";
    if (strtolower(trim($action)) == "approve") {
        $sql_query = "SELECT * from `temp_vendor` where `is_active` = '0'";
    }else if(strtolower(trim($action)) == "submit"){
        $sql_query = "SELECT * from `temp_vendor` where `created_by_id` = '$user_id' AND `is_active` = '0'";
    }
    
    $response = array();

//SELECT `id`, `Created Time`, `Last Modified Time`, `Contact ID`, `Source of Supply`, `Contact Name`, `Display Name`, `Company Name`, `Salutation`, `First Name`, `Last Name`, `EmailID`, `Phone`, `MobilePhone`, `Skype Identity`, `Facebook`, `Twitter`, `Currency Code`, `Notes`, `Website`, `GST Treatment`, `GST Identification Number (GSTIN)`, `PAN Number`, `Payment Terms`, `Contact Address ID`, `Billing Attention`, `Billing Address`, `Billing Street2`, `Billing City`, `Billing State`, `Billing Country`, `Billing Code`, `Billing Phone`, `Billing Fax`, `Shipping Attention`, `Shipping Address`, `Shipping Street2`, `Shipping City`, `Shipping State`, `Shipping Country`, `Shipping Code`, `Shipping Phone`, `Shipping Fax`, `Source`, `Last Sync Time`, `Status`, `Vendor Payment`, `CF.PAN No`, `CF.Service Tax No`, `CF.TAN No`, `CF.ADHAAR No`, `bank_name`, `bank_address`, `account_number`, `swift_code`, `iban`, `ifsc`, `bank_file_path`, `id_proof_file_path`, `created_by_id`, `is_active` FROM `temp_vendor` WHERE 1


    $result = $con->query($sql_query);
    if ($result->num_rows >0) {
        while ($row = $result->fetch_assoc()) {

             //$vendor_type = getVendorType($con,$row['CF.Vendor type']);

             $gst_treatment = $row['GST Treatment'];
            if ($gst_treatment == "business_gst") {
                $gst_treatment = "Registered Business - Regular";
            }else {
                $gst_treatment = "unregistered business";
            }

            array_push($response,array("id"=>$row['id'],"vendor_type_id"=>"0","vendor_type"=>$row['CF.Vendor type'],"first_name"=>$row['First Name'],"last_name"=>$row['Last Name'],"contact_name"=>$row['Contact Name'],"display_name"=>$row['Display Name'],"company_name"=>$row['Company Name'],"email"=>$row['EmailID'],"contact"=>$row['MobilePhone'],"gst_treatment"=>$gst_treatment,"gst_num"=>$row['GST Identification Number (GSTIN)'],"district"=>$row['CF.Vendor District'],"place_of_supply"=>$row['Source of Supply'],"payment_term"=>$row['Payment Terms'],"billing_address"=>$row['Billing Address'],"billing_city"=>$row['Billing City'],"billing_state"=>$row['Billing State'],"billing_zipcode"=>$row['Billing Code'],"billing_country"=>$row['Billing Country'],"billing_phone"=>$row['Billing Phone'],"shipping_address"=>$row['Shipping Address'],"shipping_city"=>$row['Shipping City'],"shipping_state"=>$row['Shipping State'],"shipping_zipcode"=>$row['Shipping Code'],"shipping_country"=>$row['Shipping Country'],"shipping_phone"=>$row['Shipping Phone'],"pan_number"=>$row['CF.PAN No'],"service_tax_number"=>$row['CF.Service Tax No'],"tax_number"=>$row['CF.TAN No'],"adhaar_number"=>$row['CF.ADHAAR No'],"bank_name"=>$row['CF.Name of Vendors Bank'],"bank_holder_name"=>$row['CF.Bank a/c holders name'],"bank_address"=>$row['CF.Banks Address'],"ifsc"=>$row['CF.IFSC Code'],"account_number"=>$row['CF.Bank Account number'],"bank_file"=>$row['CF.bank_file_path'],"id_proof_file"=>$row['CF.id_proof_file_path'],"created_by_id"=>$row['created_by_id'],"voter_id"=>$row['CF.Voter ID'],"rate"=>$row['CF.Rate'],"payment_mode"=>$row['CF.Payment Mode'],"bill_file"=>$row['CF.bill_file_path'],"bill_number"=>$row['CF.bill_number']));
        }
    }


    echo json_encode($response);

     function getVendorType($con,$vendor_type_id){
        $vendor_type = "";
        $result = $con->query("SELECT * from `vendor_type` WHERE `id` = '$vendor_type_id'");
        if($result->num_rows >0){
            if ($row = $result->fetch_assoc()) {
                $vendor_type = $row['type'];

            }
        }
        return $vendor_type;
    }
?>