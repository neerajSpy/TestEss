<?php
date_default_timezone_set('Asia/Kolkata');
include "config/config.php";

$trip_id = $_POST['trip_id'];
$project_id = $_POST['project_id'];
$travel_type = $_POST['travel_type'];
$travel_mode = $_POST['travel_mode'];
$member_json = json_decode($_POST['member_json']);
$admin_source = $_POST['admin_source'];
$admin_destination = $_POST['admin_destination'];
$admin_check_in = $_POST['admin_check_in'];
$admin_check_out = $_POST['admin_check_out'];
$admin_room = $_POST['admin_room'];
$admin_total_amount = $_POST['admin_total_amount'];
$admin_vendor = $_POST['admin_vendor'];
$vendor_id = $_POST['vendor_id'];
$quantity = $_POST['quantity'];
$admin_instruction = $_POST['admin_instruction'];
$payment_mode = $_POST['payment_mode'];
$payment_through = $_POST['payment_through'];
$payment_date = $_POST['payment_date'];
$total_amount = $_POST['total_amount'];
$reference_num = $_POST['reference_num'];
$bill_date = $_POST['bill_date'];
$notes = $_POST['notes'];
$created_by_id = $_POST['created_by_id'];
$current_date = date("Y-m-d h:m:s");


//SELECT `id`, `travel_type`, `travel_mode`, `user_vendor`, `user_source`, `user_destination`, `user_travel_date`, `user_instruction`, `user_check_in`, `user_check_out`, `user_room`, `user_total_amount`, `admin_vendor`, `admin_source`, `admin_destination`, `admin_travel_date`, `admin_instruction`, `admin_check_in`, `admin_check_out`, `admin_room`, `admin_total_amount`, `created_by_id`, `created_date`, `modified_by_id`, `modified_date`, `Bill Date`, `Bill ID`, `Bill Number`, `PurchaseOrder`, `Bill Status`, `Source of Supply`, `Destination of Supply`, `GST Treatment`, `GST Identification Number (GSTIN)`, `Is Inclusive Tax`, `TDS Percent`, `TDS Account`, `Vendor Name`, `Due Date`, `Currency Code`, `Exchange Rate`, `Item Name`, `Product ID`, `SKU`, `Account`, `Description`, `Quantity`, `Usage unit`, `Rate`, `HSN/SAC`, `Tax ID`, `Tax Name`, `Tax Percentage`, `Tax Amount`, `Tax Type`, `Item Exemption Code`, `Item Type`, `Reverse Charge Tax Name`, `Reverse Charge Tax Rate`, `Reverse Charge Tax Type`, `Item Total`, `ITC Eligibility`, `SubTotal`, `Is Discount Before Tax`, `Entity Discount Percent`, `Entity Discount Amount`, `Discount Account`, `Total`, `Balance`, `Adjustment`, `Adjustment Description`, `Vendor Notes`, `Terms  Conditions`, `Payment Terms`, `Payment Terms Label`, `Is Billable`, `Is Landed Cost`, `Customer Name`, `Project Name`, `Vendor Payment`, `TDSAmount`, `TDS Section`, `TDS Account Name` FROM `emp_booking` WHERE 1

$last_insert_id = 0;

$result = $con->query("INSERT INTO `emp_booking` (`trip_id`,`travel_type`, `travel_mode`,`admin_vendor`,`admin_source`,`admin_destination`,`admin_travel_date`,`admin_check_in`,`admin_check_out`,`admin_room`,`admin_total_amount`,`created_by_id`,`created_date`,`Bill Date`,`Bill Status`,`Vendor Name`,`Due Date`,`Item Name`,`Description`,`Quantity`,`Rate`,`Item Total`,`Customer Name`,`Project Name`) VALUES ('$trip_id','$travel_type','$travel_mode','$admin_vendor','$admin_source','$admin_destination','$admin_travel_date','$admin_check_in','$admin_check_out','$admin_room','$admin_total_amount','$created_by_id','$current_date','$bill_date','Booked','$admin_vendor','$payment_date','','$notes','$quantity','$admin_total_amount','$total_amount',(SELECT mzc.`Display Name` from `master_zoho_project` as mzp JOIN `master_zoho_customer` as mzc on mzc.`id` = mzp.`cust_id` WHERE mzp.`id` = '$project_id'),(SELECT `Project Name` FROM `master_zoho_project` WHERE `id` = '$project_id'))");


if ($result === TRUE) {
	$last_insert_id = $con->insert_id;

	echo "emp booking id ".$last_insert_id;
		$res = $con->query("INSERT INTO `booking_payment` (`Date`,`Vendor Name`,`EmailID`,`Mode`,`Description`,`Amount`,`Paid Through`,`Bill Number`,`Payment Type`) VALUES ('$payment_date','$admin_vendor',(SELECT `EmailID` from `master_zoho_vendor` WHERE `id` = '$vendor_id'),'$payment_mode','$notes','$total_amount','','$last_insert_id','Bill Payment')");



		/*if ($res === TRUE) {
			echo "booking payment done";
		}*/

// SELECT `id`, `user_id`, `booking_id`, `is_active`, `created_by_id`, `created_date`, `modified_date`, `modified_by_id` FROM `emp_booking_member` WHERE 1

		foreach ($member_json as $value) {
		$resMem = $con->query("INSERT into `emp_booking_member` (`booking_id`,`user_id`,`created_by_id`,`created_date`) VALUES ('$last_insert_id','$value->member_id','$created_by_id','$current_date')");

		/*if ($resMem === TRUE) {
			echo "member";
		}*/

	}

}

$response = array();
if ($last_insert_id >0) {
	$response['error'] = false;
	$response['message'] = "Successfully Saved";
}else {
	$response['error'] = true;
	$response['message'] = "Not Saved ".$con->error;
}

echo json_encode($response);
//SELECT `Payment Number`, `VendorPayment ID`, `Date`, `Vendor Name`, `Source of Supply`, `Destination of Supply`, `GST Treatment`, `GST Identification Number (GSTIN)`, `EmailID`, `Mode`, `Description`, `Description of Supply`, `Exchange Rate`, `Amount`, `Paid Through`, `Tax Account`, `Reference Number`, `PIPayment ID`, `Bill Number`, `Bill Amount`, `ReverseCharge Tax Percentage`, `ReverseCharge Tax Type`, `Reverse Charge Tax Amount`, `ReverseCharge Tax Name`, `Payment Type`, `Withholding Tax Amount`, `TDSAmount`, `TDS Section`, `TDS Account Name`, `Unused Amount` FROM `booking_payment` WHERE 1

