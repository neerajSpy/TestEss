<?php
include "config/config.php";


$emp_id = $_POST['emp_id'];
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$leave_type = $_POST['leave_type'];

$start_date_leave_type = $_POST['start_date_leave_type'];
$end_date_leave_type = $_POST['end_date_leave_type'];
$request_date = $_POST['request_date'];
$description = $_POST['description'];
$reason = $_POST['reason'];
$leave_location = $_POST['leave_location'];
$status = "pending";

//SELECT `id`, `emp_id`, `total_leaves`, `used_leave`, `leave_type_id`, `from_date`, `to_date`, `credited_date`, `note`, `entitlement_type`, `deleted`, `created_by_id`, `created_by_name` FROM `employee_leave_entitlement` WHERE 1


$datetime1 = new DateTime('2009-10-11');
$datetime2 = new DateTime('2009-10-30');
$interval = $datetime1->diff($datetime2);
echo $interval->format('%R%a days');

echo json_encode(array("attendance"=>$attendance_response,"leave_response"=>$leave_response));
?>
