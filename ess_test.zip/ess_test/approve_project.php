<?php
include "config/config.php";
date_default_timezone_set('Asia/Kolkata');

$project_id = $_POST['project_id'];
$user_id = $_POST['user_id'];
$client_name = $_POST['client_name'];
$customer_id = $_POST['customer_id'];
$customer_name = $_POST['customer_name'];
$project_name = $_POST['project_name'];
$billing_type = $_POST['billing_type'];
$budget_amount = $_POST['budget_amount'];
$project_type_id = $_POST['project_type_id'];
$description = $_POST['description'];
$location = $_POST['location'];
$district = $_POST['district'];
$address = $_POST['address'];
$state = $_POST['state'];
$country = $_POST['country'];
$estimated_days = $_POST['estimated_days'];
$project_budget_hours = $_POST['project_budget_hours'];
$start_date = $_POST['start_date'];
$end_date = $_POST['estimated_end_date'];
$created_by_id = $_POST['created_by_id'];
$tl_ts_approver_id = $_POST['tl_ts_approver_id'];


$date = new DateTime($end_date);
$now = new DateTime($start_date);

$days = $date->diff($now)->format("%d");
$currency_code = "INR";
$budget_type = "No Budget";

$response = array();

$now = new DateTime();
$current_date =  $now->format('Y-m-d H:i:s');


if ($budget_amount == "") {
    $budget_amount = 0;
}

if ($tl_ts_approver_id == "") {
    $tl_ts_approver_id = 3;
}

$update_project_id = -1;
$activity_user_id = -1;

$emailResponse =array('user_id' =>$user_id,"created_by_id"=>$created_by_id,'customer_name'=>$customer_name,'project_name' =>$project_name,'project_type_id'=>$project_type_id,"billing_type"=>$billing_type,"budget_amount"=>$budget_amount,'project_budget_hours'=>$project_budget_hours,'start_date'=>$start_date,'end_date'=>$end_date,'description'=>$description);


//SELECT `id`, `Project Name`, `Description`, `Billing Type`, `Project Cost`, `Customer Name`, `client_name`, `cust_id`, `Currency Code`, `project_type_id`, `Budget Type`, `Budget Amount`, `Project Budget Hours`, `CF.Estimated Days`, `tl_ts_approver_id`, `planned_start_date`, `planned_end_date`, `actual_start_date`, `actual_end_date`, `created_by`, `modified_by`, `is_active`, `created_date`, `modified_date`, `project_status`, `location`, `district`, `address` FROM `master_zoho_project` WHERE 1

$result = $con->query("SELECT * from `master_zoho_project` where `Project Name` = '$project_name' AND `project_type_id` = '$project_type_id'");


if ($result->num_rows < 1) {

    $update_project_id = 0;
    
    $insert_query = "INSERT INTO `master_zoho_project` (`Project Name`,`address`,`district`,`location`, `Description`,`client_name`,`Customer Name`, `cust_id`,`Currency Code`,`project_type_id`,`CF.Estimated Days`,`planned_start_date`,`planned_end_date`,`created_by`,`created_date`,`Billing Type`,`Budget Type`,`Project Budget Hours`,`Budget Amount`,`tl_ts_approver_id`,`country`,`state`) VALUES ('$project_name','$address','$district','$location', '$description','$client_name','$customer_name','$customer_id','$currency_code','$project_type_id','$estimated_days','$start_date','$end_date','$user_id','$current_date','$billing_type','$budget_type','$project_budget_hours','$budget_amount','$tl_ts_approver_id','$country','$state')";

    if ($con->query($insert_query) === TRUE) {
        $update_project_id = $con->insert_id;

        //echo "project ".$update_project_id;
        
        $project_type_list = $con->query("SELECT * from `project_type_activity_type` WHERE `project_type_id` = '$project_type_id'");

        if ($project_type_list->num_rows >0) {

            while ($row = $project_type_list->fetch_array()) {
                $activity_type_id = $row['id'];
                $query = "INSERT INTO `activity` (`project_id`,`project_type_id`,`activity_type_id`,`created_by_id`,`created_date`) VALUES('$update_project_id','$project_type_id','$activity_type_id','$user_id','$current_date')";

                if ($con->query($query) === TRUE) {
                }
            }

            //echo "project id".$update_project_id;
          $res = $con->query("UPDATE `temp_project` set `is_active` = '1' WHERE `id` = '$project_id'");
           $activity_user_id = assignProjectToUser($con,$created_by_id,$update_project_id,$project_type_id);        
        }
    }
}else {
    $update_project_id = getProjectId($con,$project_name,$project_type_id);
    $res = $con->query("UPDATE `temp_project` set `is_active` = '1' WHERE `id` = '$project_id'");
    $activity_user_id =  assignProjectToUser($con,$created_by_id,$update_project_id,$project_type_id);
}

if ($update_project_id > 0) {
    $response['id'] = $update_project_id;
    $response['activity_user_id'] = $activity_user_id;
    $response['error'] = false;
    $response['message'] = "Successfully Saved. Assign to user ";

    sendNotification($con,$created_by_id,$project_name);
    sendEmail($con,$emailResponse);

}else if ($update_project_id == -1){
    $response['id'] = $project_id;
    $response['activity_user_id'] = $activity_user_id;
    $response['error'] = false;
    $response['message'] = "Project exist. Assign to user";

    sendNotification($con,$created_by_id,$project_name);
    sendEmail($con,$emailResponse);

}else{
    $response['id'] = $update_project_id;
    $response['activity_user_id'] = '0';
    $response['error'] = true;
    $response['message'] = "Project not Created.";
}

echo json_encode($response);



function getProjectId($con,$project_name,$project_type_id){
    $project_id = 0;
    $result = $con->query("SELECT * from `master_zoho_project` WHERE `Project Name` = '$project_name' AND `project_type_id` = '$project_type_id'");

    //echo " get project id ".$result->num_rows;

    if ($result->num_rows >0) {
        if ($row = $result->fetch_assoc()) {
            $project_id = $row['id'];
        }
    }
    return $project_id;
}


function assignProjectToUser($con,$created_by_id,$project_id,$project_type_id){

    //echo "get ".$project_id." ".$project_type_id." ".$created_by_id."\n";
    $activity_user_id = 0;
    $inv_row = $con->query("SELECT * FROM `activity_user` WHERE `project_id` = '$project_id' AND `user_id` = '$created_by_id' AND `is_active` = '1'");
    if ($inv_row->num_rows < 1) {

        //echo "already not exist.\n";
        $assign_project = $con->query("INSERT INTO `project_user` (`project_id`,`user_id`,`create_by_id`,`create_date`) VALUES ('$project_id','$created_by_id','$user_id','$current_date')");

        $activity_result = $con->query("SELECT DISTINCT `id`,`activity_type_id` from `activity` WHERE `project_id` = 'project_id' AND `project_type_id` = '$project_type_id'");

        if ($activity_result->num_rows >0) {
            while ($row = $activity_result->fetch_assoc()) {

            
                $id = $row['id'];
                $activity_type_id = $row['activity_type_id'];
                //echo "activity_id ".$id." ".$activity_type_id."\n";
                $insert_query = "INSERT INTO `activity_user` (`project_id`,`activity_id`,`activity_type_id`,`user_id`,`created_by_id`,`created_date`) VALUES ('$project_id','$id','$activity_type_id','$created_by_id','$user_id','$current_date')";
                if ($con->query($insert_query) === TRUE) {
                    $activity_user_id = $con->insert_id;
                    //echo "user activity ".$activity_user_id."\n";
                }    
            }

        }
    }
    return $activity_user_id;
}


function sendNotification($con,$user_id,$project_name){
    $userData = getUserArray($con,$user_id);
    $token_query = "SELECT `token` from `user_fcm_token` WHERE `user_id` = '$user_id'";
    $ss= $con->query($token_query);

    $ch = curl_init("https://fcm.googleapis.com/fcm/send");
    $serverKey = "AIzaSyDJ0MiSBWBsQN5y-ybhWr2GNGFzTPsSfFQ";

    $notificationArr = array();
    array_push($notificationArr,array("project_name"=>$project_name,"user_name"=>$userData['name']));

    $notification = array("body" => array("module"=>"Assign Project","json_response"=>$notificationArr));

    while($r= ($ss->fetch_array())) {

        $f = $r['token'];
        $arrayToSend = array('to' => $f, 'data' => $notification);

        $json = json_encode($arrayToSend);
      // echo $json;
        $headers = array();
        $headers[] = "Content-Type: application/json";
        $headers[] = "Authorization: key= $serverKey";

        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
        curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $result = curl_exec($ch);
        if($result === false)
        {
            //echo  'Curl failed ' . curl_error($ch);
        }

    }
    curl_close($ch);
}


function getUserArray($con,$user_id){
    $userArray = array();
    $result = $con->query("SELECT * from `user` WHERE `id` = '$user_id'");
    if ($result->num_rows >0) {
       if($row = $result->fetch_array()){
        $userArray = $row;
    }
    }
    

    return $userArray;
}

function getProjectType($con,$type_id){
    $type = "";
    $result = $con->query("SELECT * From `project_type` WHERE `id` = '$type_id'");
    if ($result->num_rows >0) {
        if ($row = $result->fetch_assoc()) {
            $type = $row['type'];
        }
    }
    return $type;
}

function sendEmail($con,$emailResponse){

//('user_id' => ,$user_id,'customer_name'=>$customer_name,'project_name' =>$project_name,'project_type_id'=>$project_type_id,"billing_type"=>$billing_type,"budget_amount"=>$budget_amount,'project_budget_hours'=>$project_budget_hours,'start_date'=>$start_date,'end_date'=>$end_date,'description'=>$description)
    $project_type = getProjectType($con,$emailResponse['project_type_id']);
    $userArray = getUserArray($con,$emailResponse['created_by_id']);

// Multiple recipients
$to =  "ranju.kumari@technitab.in, kavinder.kohli@technitab.com"; // note the comma
$from = $userArray['email'];

// Subject
$subject = 'Add/Approve : '.$userArray['name'];

// Message
$message = '
<html>

<body>
Dear Admin,
<p>Please approve the following project request submitted by '.$userArray['name'].' as per information below </p>
Customer Name : '.$emailResponse['customer_name'].'<br>
Project Name : '.$emailResponse['project_name'].'<br>
Project Type : '.$project_type.'<br>
Billing Type : '.$emailResponse['billing_type'].'<br>
Budget Amount : '.$emailResponse['budget_amount'].'<br>
Project Budget hour : '.$emailResponse['project_budget_hours'].'<br>
Start date : '.$emailResponse['start_date'].'<br>
End date : '.$emailResponse['end_date'].'<br>
Description : '.$emailResponse['description'].'<br>

<p></p>
Regards.<br>
Ess App
</body>
</html>
';

// To send HTML mail, the Content-type header must be set
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-type: text/html; charset=iso-8859-1';

// Additional headers
$headers[] = 'To: '.$to;
$headers[] = 'From: '.$userArray['name'].' '.$userArray['email'];
$headers[] = 'Bcc: neeraj.kumar@technitab.in';
/*$headers[] = 'Bcc: birthdaycheck@example.com';*/

// Mail it
mail($to, $subject, $message, implode("\r\n", $headers));

}


?>